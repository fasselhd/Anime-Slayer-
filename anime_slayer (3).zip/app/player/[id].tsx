import AsyncStorage from "@react-native-async-storage/async-storage";
import { router, useLocalSearchParams } from "expo-router";
import * as Brightness from "expo-brightness";
import * as Haptics from "expo-haptics";
import { useKeepAwake } from "expo-keep-awake";
import { VideoView, useVideoPlayer } from "expo-video";
import { useEvent } from "expo";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Dimensions,
  PanResponder,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  Modal,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { trpc } from "@/lib/trpc";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");
const SEEK_SECONDS = 10;
const SPEEDS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds) || seconds < 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function VolumeIcon({ level }: { level: number }) {
  if (level === 0) return <Text style={styles.gestureIcon}>🔇</Text>;
  if (level < 0.4) return <Text style={styles.gestureIcon}>🔈</Text>;
  if (level < 0.7) return <Text style={styles.gestureIcon}>🔉</Text>;
  return <Text style={styles.gestureIcon}>🔊</Text>;
}

function BrightnessIcon({ level }: { level: number }) {
  if (level < 0.4) return <Text style={styles.gestureIcon}>🌙</Text>;
  return <Text style={styles.gestureIcon}>☀️</Text>;
}

export default function PlayerScreen() {
  useKeepAwake();
  useInterstitialAd();

  const { id } = useLocalSearchParams<{ id: string }>();
  const episodeId = parseInt(id ?? "0");
  const insets = useSafeAreaInsets();

  // ─── Data ─────────────────────────────────────────────────────────
  const { data: episode, isLoading } = trpc.episodes.byId.useQuery({ id: episodeId });
  const { data: anime } = trpc.anime.byId.useQuery(
    { id: episode?.animeId ?? 0 },
    { enabled: !!episode?.animeId }
  );
  const { data: allEpisodes } = trpc.episodes.byAnimeId.useQuery(
    { animeId: episode?.animeId ?? 0 },
    { enabled: !!episode?.animeId }
  );
  const incrementViews = trpc.episodes.incrementViews.useMutation();

  // ─── Player state ─────────────────────────────────────────────────
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isBuffering, setIsBuffering] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [speed, setSpeed] = useState(1.0);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showEpisodeList, setShowEpisodeList] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPreviewTime, setSeekPreviewTime] = useState(0);

  // ─── Gesture state ────────────────────────────────────────────────
  const [gestureType, setGestureType] = useState<"brightness" | "volume" | "seek" | null>(null);
  const [gestureValue, setGestureValue] = useState(0);
  const [brightnessLevel, setBrightnessLevel] = useState(0.5);
  const [volumeLevel, setVolumeLevel] = useState(1.0);

  // ─── Refs ─────────────────────────────────────────────────────────
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const gestureOpacity = useRef(new Animated.Value(0)).current;
  const videoRef = useRef<VideoView>(null);
  const gestureStartX = useRef(0);
  const gestureStartY = useRef(0);
  const gestureStartValue = useRef(0);
  const gestureDir = useRef<"h" | "v" | null>(null);
  const progressBarWidth = useRef(0);

  // ─── Video source ─────────────────────────────────────────────────
  const videoUrl = episode?.videoUrl720p || episode?.videoUrl || episode?.videoUrl480p || "";

  const player = useVideoPlayer(videoUrl ? { uri: videoUrl } : null, (p) => {
    p.loop = false;
    p.play();
  });

  // ─── Events ───────────────────────────────────────────────────────
  const { isPlaying: playerPlaying } = useEvent(player, "playingChange", {
    isPlaying: player.playing,
  });
  const { status } = useEvent(player, "statusChange", { status: player.status });

  useEffect(() => { setIsPlaying(playerPlaying); }, [playerPlaying]);
  useEffect(() => { setIsBuffering(status === "loading"); }, [status]);

  // ─── Increment views ──────────────────────────────────────────────
  useEffect(() => {
    if (episodeId) incrementViews.mutate({ id: episodeId });
  }, [episodeId]);

  // ─── Progress tracking ────────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isSeeking) {
        const ct = player.currentTime ?? 0;
        const dur = player.duration ?? 0;
        setCurrentTime(ct);
        setDuration(dur);
        if (dur > 0) {
          Animated.timing(progressAnim, {
            toValue: ct / dur,
            duration: 400,
            useNativeDriver: false,
          }).start();
        }
        // Auto-save progress
        if (Math.floor(ct) % 15 === 0 && ct > 5 && episode?.animeId) {
          AsyncStorage.setItem(
            `progress_ep_${episodeId}`,
            JSON.stringify({ time: ct, duration: dur })
          ).catch(() => {});
        }
      }
    }, 500);
    return () => clearInterval(interval);
  }, [player, isSeeking, episodeId, episode?.animeId, progressAnim]);

  // ─── Restore progress ─────────────────────────────────────────────
  useEffect(() => {
    AsyncStorage.getItem(`progress_ep_${episodeId}`).then((val) => {
      if (val) {
        const { time } = JSON.parse(val);
        if (time > 30) {
          setTimeout(() => { player.currentTime = time; }, 1200);
        }
      }
    }).catch(() => {});
  }, [episodeId, player]);

  // ─── Brightness init ──────────────────────────────────────────────
  useEffect(() => {
    if (Platform.OS !== "web") {
      Brightness.getBrightnessAsync().then(setBrightnessLevel).catch(() => {});
    }
  }, []);

  // ─── Auto-hide controls ───────────────────────────────────────────
  const resetControlsTimer = useCallback(() => {
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    setShowControls(true);
    controlsTimer.current = setTimeout(() => {
      setShowControls(false);
    }, 4000);
  }, []);

  useEffect(() => {
    resetControlsTimer();
    return () => { if (controlsTimer.current) clearTimeout(controlsTimer.current); };
  }, []);

  // ─── Gesture indicator ───────────────────────────────────────────
  const flashGestureIndicator = useCallback(
    (type: "brightness" | "volume" | "seek", val: number) => {
      setGestureType(type);
      setGestureValue(val);
      gestureOpacity.setValue(1);
      Animated.sequence([
        Animated.delay(700),
        Animated.timing(gestureOpacity, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]).start(() => setGestureType(null));
    },
    [gestureOpacity]
  );

  // ─── PanResponder ────────────────────────────────────────────────
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !isLocked,
      onMoveShouldSetPanResponder: (_, gs) =>
        !isLocked && (Math.abs(gs.dx) > 8 || Math.abs(gs.dy) > 8),
      onPanResponderGrant: (e) => {
        gestureStartX.current = e.nativeEvent.pageX;
        gestureStartY.current = e.nativeEvent.pageY;
        gestureStartValue.current = player.currentTime ?? 0;
        gestureDir.current = null;
      },
      onPanResponderMove: (e, gs) => {
        const { dx, dy } = gs;
        if (!gestureDir.current) {
          if (Math.abs(dx) > Math.abs(dy) * 1.5) gestureDir.current = "h";
          else if (Math.abs(dy) > Math.abs(dx) * 1.5) gestureDir.current = "v";
        }
        if (gestureDir.current === "h") {
          const seekDelta = (dx / SCREEN_WIDTH) * 120;
          const newTime = Math.max(0, Math.min(player.duration ?? 0, gestureStartValue.current + seekDelta));
          setSeekPreviewTime(newTime);
          setIsSeeking(true);
        } else if (gestureDir.current === "v") {
          const isRight = gestureStartX.current > SCREEN_WIDTH / 2;
          const delta = (-dy / SCREEN_HEIGHT) * 1.5;
          if (isRight) {
            const newVol = Math.max(0, Math.min(1, volumeLevel + delta));
            setVolumeLevel(newVol);
            player.volume = newVol;
          } else if (Platform.OS !== "web") {
            const newBr = Math.max(0.05, Math.min(1, brightnessLevel + delta));
            setBrightnessLevel(newBr);
            Brightness.setBrightnessAsync(newBr).catch(() => {});
          }
        }
      },
      onPanResponderRelease: () => {
        if (gestureDir.current === "h" && isSeeking) {
          player.currentTime = seekPreviewTime;
          setIsSeeking(false);
        } else if (gestureDir.current === "v") {
          const isRight = gestureStartX.current > SCREEN_WIDTH / 2;
          if (isRight) flashGestureIndicator("volume", volumeLevel);
          else flashGestureIndicator("brightness", brightnessLevel);
        }
        gestureDir.current = null;
      },
    })
  ).current;

  // ─── Actions ─────────────────────────────────────────────────────
  const togglePlay = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (player.playing) player.pause(); else player.play();
    resetControlsTimer();
  }, [player, resetControlsTimer]);

  const seekForward = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    player.seekBy(SEEK_SECONDS);
    flashGestureIndicator("seek", SEEK_SECONDS);
    resetControlsTimer();
  }, [player, flashGestureIndicator, resetControlsTimer]);

  const seekBackward = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    player.seekBy(-SEEK_SECONDS);
    flashGestureIndicator("seek", -SEEK_SECONDS);
    resetControlsTimer();
  }, [player, flashGestureIndicator, resetControlsTimer]);

  const changeSpeed = useCallback((s: number) => {
    player.playbackRate = s;
    setSpeed(s);
    setShowSpeedMenu(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    resetControlsTimer();
  }, [player, resetControlsTimer]);

  const togglePiP = useCallback(async () => {
    try { await videoRef.current?.startPictureInPicture(); } catch {}
  }, []);

  const handleScreenTap = useCallback(() => {
    if (isLocked) return;
    if (showSpeedMenu) { setShowSpeedMenu(false); return; }
    if (showEpisodeList) { setShowEpisodeList(false); return; }
    resetControlsTimer();
  }, [isLocked, showSpeedMenu, showEpisodeList, resetControlsTimer]);

  const currentIndex = allEpisodes?.findIndex((ep) => ep.id === episodeId) ?? -1;
  const prevEpisode = currentIndex > 0 ? allEpisodes?.[currentIndex - 1] : null;
  const nextEpisode = allEpisodes && currentIndex < allEpisodes.length - 1 ? allEpisodes[currentIndex + 1] : null;

  // ─── Loading state ────────────────────────────────────────────────
  if (isLoading) {
    return (
      <View style={styles.centerScreen}>
        <StatusBar hidden />
        <ActivityIndicator size="large" color="#E53935" />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  if (!episode || !videoUrl) {
    return (
      <View style={styles.centerScreen}>
        <StatusBar hidden />
        <Text style={{ fontSize: 48 }}>📺</Text>
        <Text style={styles.errorText}>رابط الفيديو غير متاح</Text>
        <TouchableOpacity style={styles.backBtnRed} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>← العودة</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <View style={styles.container}>
      <StatusBar hidden />

      {/* ── Video ── */}
      <View style={styles.videoContainer} {...panResponder.panHandlers}>
        <VideoView
          ref={videoRef}
          player={player}
          style={styles.video}
          contentFit="contain"
          allowsFullscreen={false}
          allowsPictureInPicture
          nativeControls={false}
        />

        {/* Tap to toggle controls */}
        <Pressable style={StyleSheet.absoluteFill} onPress={handleScreenTap} />

        {/* ── Buffering ── */}
        {isBuffering && !isSeeking && (
          <View style={styles.bufferingOverlay}>
            <ActivityIndicator size="large" color="#fff" />
            <Text style={styles.bufferingText}>جاري التحميل...</Text>
          </View>
        )}

        {/* ── Seek preview ── */}
        {isSeeking && (
          <View style={styles.seekOverlay}>
            <Text style={styles.seekIcon}>{seekPreviewTime > (player.currentTime ?? 0) ? "⏩" : "⏪"}</Text>
            <Text style={styles.seekTime}>{formatTime(seekPreviewTime)}</Text>
            <Text style={styles.seekDuration}>/ {formatTime(duration)}</Text>
            <View style={styles.seekProgressBar}>
              <View style={[styles.seekProgressFill, { width: `${duration > 0 ? (seekPreviewTime / duration) * 100 : 0}%` }]} />
            </View>
          </View>
        )}

        {/* ── Gesture indicator ── */}
        {gestureType && (
          <Animated.View
            style={[
              styles.gestureIndicator,
              gestureType === "volume" ? styles.gestureRight : styles.gestureLeft,
              { opacity: gestureOpacity },
            ]}
          >
            {gestureType === "brightness" ? (
              <BrightnessIcon level={brightnessLevel} />
            ) : gestureType === "volume" ? (
              <VolumeIcon level={volumeLevel} />
            ) : (
              <Text style={styles.gestureIcon}>{gestureValue > 0 ? "⏩" : "⏪"}</Text>
            )}
            <Text style={styles.gestureLabel}>
              {gestureType === "brightness"
                ? `${Math.round(brightnessLevel * 100)}%`
                : gestureType === "volume"
                  ? `${Math.round(volumeLevel * 100)}%`
                  : `${gestureValue > 0 ? "+" : ""}${gestureValue}s`}
            </Text>
            <View style={styles.gestureBarTrack}>
              <View
                style={[
                  styles.gestureBarFill,
                  {
                    width: `${Math.round(
                      (gestureType === "brightness" ? brightnessLevel : gestureType === "volume" ? volumeLevel : 0.5) * 100
                    )}%`,
                  },
                ]}
              />
            </View>
          </Animated.View>
        )}

        {/* ── Lock overlay ── */}
        {isLocked && (
          <View style={styles.lockOverlay}>
            <TouchableOpacity
              style={styles.unlockBtn}
              onPress={() => {
                setIsLocked(false);
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              }}
            >
              <Text style={styles.lockIconText}>🔒</Text>
              <Text style={styles.unlockText}>اضغط للفتح</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── Controls overlay ── */}
        {showControls && !isLocked && (
          <View style={[styles.controlsOverlay, { paddingTop: insets.top }]}>

            {/* Top bar */}
            <View style={styles.topBar}>
              <TouchableOpacity style={styles.iconBtn} onPress={() => { player.pause(); router.back(); }}>
                <Text style={styles.backArrow}>←</Text>
              </TouchableOpacity>

              <View style={styles.titleBlock}>
                <Text style={styles.animeTitleText} numberOfLines={1}>
                  {anime?.titleAr || anime?.title}
                </Text>
                <Text style={styles.episodeTitleText} numberOfLines={1}>
                  الحلقة {episode.number}{episode.titleAr ? ` - ${episode.titleAr}` : ""}
                </Text>
              </View>

              <View style={styles.topRight}>
                <TouchableOpacity style={styles.iconBtn} onPress={togglePiP}>
                  <Text style={styles.iconBtnText}>⧉</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.iconBtn}
                  onPress={() => {
                    setIsLocked(true);
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  }}
                >
                  <Text style={styles.iconBtnText}>🔓</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Center controls */}
            <View style={styles.centerRow}>
              {/* Prev episode */}
              <TouchableOpacity
                style={[styles.epNavBtn, !prevEpisode && styles.dimmed]}
                onPress={() => prevEpisode && router.replace(`/player/${prevEpisode.id}` as any)}
                disabled={!prevEpisode}
              >
                <Text style={styles.epNavIcon}>⏮</Text>
                <Text style={styles.epNavLabel}>السابقة</Text>
              </TouchableOpacity>

              {/* Seek -10 */}
              <TouchableOpacity style={styles.seekCircle} onPress={seekBackward}>
                <Text style={styles.seekCircleIcon}>⏪</Text>
                <Text style={styles.seekCircleLabel}>10</Text>
              </TouchableOpacity>

              {/* Play/Pause */}
              <TouchableOpacity style={styles.playCircle} onPress={togglePlay}>
                {isBuffering ? (
                  <ActivityIndicator color="#fff" size="large" />
                ) : (
                  <Text style={styles.playCircleIcon}>{isPlaying ? "⏸" : "▶"}</Text>
                )}
              </TouchableOpacity>

              {/* Seek +10 */}
              <TouchableOpacity style={styles.seekCircle} onPress={seekForward}>
                <Text style={styles.seekCircleIcon}>⏩</Text>
                <Text style={styles.seekCircleLabel}>10</Text>
              </TouchableOpacity>

              {/* Next episode */}
              <TouchableOpacity
                style={[styles.epNavBtn, !nextEpisode && styles.dimmed]}
                onPress={() => nextEpisode && router.replace(`/player/${nextEpisode.id}` as any)}
                disabled={!nextEpisode}
              >
                <Text style={styles.epNavIcon}>⏭</Text>
                <Text style={styles.epNavLabel}>التالية</Text>
              </TouchableOpacity>
            </View>

            {/* Bottom controls */}
            <View style={[styles.bottomBar, { paddingBottom: insets.bottom + 6 }]}>
              {/* Time */}
              <Text style={styles.timeLabel}>{formatTime(currentTime)}</Text>

              {/* Progress bar */}
              <View
                style={styles.progressWrapper}
                onLayout={(e) => { progressBarWidth.current = e.nativeEvent.layout.width; }}
              >
                <Pressable
                  style={styles.progressTouchArea}
                  onPress={(e) => {
                    const ratio = e.nativeEvent.locationX / progressBarWidth.current;
                    player.currentTime = ratio * (player.duration ?? 0);
                    resetControlsTimer();
                  }}
                >
                  {/* Track */}
                  <View style={styles.progressTrack}>
                    {/* Fill */}
                    <Animated.View
                      style={[
                        styles.progressFill,
                        {
                          width: progressAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: ["0%", "100%"],
                          }),
                        },
                      ]}
                    />
                    {/* Thumb */}
                    <Animated.View
                      style={[
                        styles.progressThumb,
                        {
                          left: progressAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: ["0%", "100%"],
                          }),
                        },
                      ]}
                    />
                  </View>
                </Pressable>
              </View>

              {/* Duration */}
              <Text style={styles.timeLabel}>{formatTime(duration)}</Text>

              {/* Speed */}
              <TouchableOpacity
                style={styles.speedPill}
                onPress={() => { setShowSpeedMenu(true); resetControlsTimer(); }}
              >
                <Text style={styles.speedPillText}>{speed === 1 ? "1x" : `${speed}x`}</Text>
              </TouchableOpacity>

              {/* Episodes list */}
              <TouchableOpacity
                style={styles.epListBtn}
                onPress={() => { setShowEpisodeList(true); resetControlsTimer(); }}
              >
                <Text style={styles.epListIcon}>☰</Text>
              </TouchableOpacity>
            </View>

            {/* Episode counter badge */}
            <View style={styles.epCounterBadge}>
              <Text style={styles.epCounterText}>
                {episode.number} / {allEpisodes?.length ?? "?"}
              </Text>
            </View>
          </View>
        )}
      </View>

      {/* ── Info panel below video ── */}
      <ScrollView style={styles.infoPanel} contentContainerStyle={styles.infoPanelContent}>
        <Text style={styles.infoPanelTitle}>
          {anime?.titleAr || anime?.title} — الحلقة {episode.number}
        </Text>
        {episode.titleAr && (
          <Text style={styles.infoPanelEpTitle}>{episode.titleAr}</Text>
        )}
        {episode.synopsis && (
          <Text style={styles.infoPanelSynopsis}>{episode.synopsis}</Text>
        )}

        {/* Quality selector */}
        {(episode.videoUrl480p || episode.videoUrl720p) && (
          <View style={styles.qualitySection}>
            <Text style={styles.qualitySectionTitle}>الجودة</Text>
            <View style={styles.qualityRow}>
              {episode.videoUrl480p && (
                <TouchableOpacity
                  style={[
                    styles.qualityBtn,
                    videoUrl === episode.videoUrl480p && styles.qualityBtnActive,
                  ]}
                  onPress={() => {
                    player.replaceAsync({ uri: episode.videoUrl480p! });
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }}
                >
                  <Text style={[styles.qualityBtnText, videoUrl === episode.videoUrl480p && styles.qualityBtnTextActive]}>
                    480p
                  </Text>
                </TouchableOpacity>
              )}
              {episode.videoUrl720p && (
                <TouchableOpacity
                  style={[
                    styles.qualityBtn,
                    videoUrl === episode.videoUrl720p && styles.qualityBtnActive,
                  ]}
                  onPress={() => {
                    player.replaceAsync({ uri: episode.videoUrl720p! });
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }}
                >
                  <Text style={[styles.qualityBtnText, videoUrl === episode.videoUrl720p && styles.qualityBtnTextActive]}>
                    720p HD
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}

        {/* Episode chips */}
        {allEpisodes && allEpisodes.length > 1 && (
          <View style={styles.epChipsSection}>
            <Text style={styles.epChipsSectionTitle}>جميع الحلقات</Text>
            <View style={styles.epChipsGrid}>
              {allEpisodes.map((ep) => (
                <TouchableOpacity
                  key={ep.id}
                  style={[
                    styles.epChip,
                    ep.id === episodeId && styles.epChipActive,
                  ]}
                  onPress={() => {
                    if (ep.id !== episodeId) {
                      router.replace(`/player/${ep.id}` as any);
                    }
                  }}
                >
                  <Text style={[styles.epChipText, ep.id === episodeId && styles.epChipTextActive]}>
                    {ep.number}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      </ScrollView>

      {/* ── Speed Menu Modal ── */}
      <Modal visible={showSpeedMenu} transparent animationType="fade" onRequestClose={() => setShowSpeedMenu(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setShowSpeedMenu(false)}>
          <View style={styles.speedMenu}>
            <Text style={styles.speedMenuTitle}>⚡ سرعة التشغيل</Text>
            {SPEEDS.map((s) => (
              <TouchableOpacity
                key={s}
                style={[styles.speedOption, speed === s && styles.speedOptionActive]}
                onPress={() => changeSpeed(s)}
              >
                <Text style={[styles.speedOptionText, speed === s && styles.speedOptionTextActive]}>
                  {s === 1.0 ? "عادي (1x)" : `${s}x`}
                </Text>
                {speed === s && <Text style={styles.checkMark}>✓</Text>}
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>

      {/* ── Episodes List Modal ── */}
      <Modal visible={showEpisodeList} transparent animationType="slide" onRequestClose={() => setShowEpisodeList(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setShowEpisodeList(false)}>
          <View style={styles.epListModal}>
            <View style={styles.epListModalHeader}>
              <Text style={styles.epListModalTitle}>📋 قائمة الحلقات</Text>
              <TouchableOpacity onPress={() => setShowEpisodeList(false)}>
                <Text style={styles.epListClose}>✕</Text>
              </TouchableOpacity>
            </View>
            <FlatList
              data={allEpisodes ?? []}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.epListItem, item.id === episodeId && styles.epListItemActive]}
                  onPress={() => {
                    setShowEpisodeList(false);
                    if (item.id !== episodeId) router.replace(`/player/${item.id}` as any);
                  }}
                >
                  <View style={styles.epListItemLeft}>
                    <Text style={[styles.epListItemNum, item.id === episodeId && styles.epListItemNumActive]}>
                      {item.number}
                    </Text>
                    {item.id === episodeId && <View style={styles.playingDot} />}
                  </View>
                  <View style={styles.epListItemInfo}>
                    <Text style={styles.epListItemTitle} numberOfLines={1}>
                      {item.titleAr || `الحلقة ${item.number}`}
                    </Text>
                    {item.duration && (
                      <Text style={styles.epListItemDuration}>{item.duration}</Text>
                    )}
                  </View>
                  {item.id === episodeId && (
                    <View style={styles.nowPlayingBadge}>
                      <Text style={styles.nowPlayingText}>▶ يعرض</Text>
                    </View>
                  )}
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <Text style={styles.emptyText}>لا توجد حلقات</Text>
              }
            />
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  centerScreen: {
    flex: 1, backgroundColor: "#000",
    justifyContent: "center", alignItems: "center", gap: 16,
  },
  loadingText: { color: "#fff", fontSize: 14 },
  errorText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  backBtnRed: {
    backgroundColor: "#E53935", paddingHorizontal: 24, paddingVertical: 12,
    borderRadius: 24, marginTop: 8,
  },
  backBtnText: { color: "#fff", fontWeight: "700", fontSize: 15 },

  // Video
  videoContainer: {
    width: SCREEN_WIDTH,
    height: SCREEN_WIDTH * (9 / 16),
    backgroundColor: "#000",
    justifyContent: "center",
  },
  video: { width: "100%", height: "100%" },

  // Buffering
  bufferingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center", alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)", gap: 12,
  },
  bufferingText: { color: "#fff", fontSize: 13 },

  // Seek preview
  seekOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center", alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.6)", gap: 6,
  },
  seekIcon: { fontSize: 36 },
  seekTime: { color: "#fff", fontSize: 40, fontWeight: "800" },
  seekDuration: { color: "rgba(255,255,255,0.6)", fontSize: 16 },
  seekProgressBar: {
    width: "60%", height: 4, backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 2, overflow: "hidden", marginTop: 8,
  },
  seekProgressFill: { height: "100%", backgroundColor: "#E53935", borderRadius: 2 },

  // Gesture indicator
  gestureIndicator: {
    position: "absolute", top: "25%",
    backgroundColor: "rgba(0,0,0,0.8)", borderRadius: 16,
    padding: 16, alignItems: "center", minWidth: 110, gap: 6,
  },
  gestureLeft: { left: 20 },
  gestureRight: { right: 20 },
  gestureIcon: { fontSize: 30 },
  gestureLabel: { color: "#fff", fontSize: 18, fontWeight: "700" },
  gestureBarTrack: {
    width: 90, height: 4, backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 2, overflow: "hidden",
  },
  gestureBarFill: { height: "100%", backgroundColor: "#fff", borderRadius: 2 },

  // Lock
  lockOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center", alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.25)",
  },
  unlockBtn: {
    alignItems: "center", backgroundColor: "rgba(0,0,0,0.7)",
    borderRadius: 20, padding: 24, gap: 8,
  },
  lockIconText: { fontSize: 36 },
  unlockText: { color: "#fff", fontSize: 13 },

  // Controls overlay
  controlsOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "space-between",
    backgroundColor: "rgba(0,0,0,0.4)",
  },

  // Top bar
  topBar: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 14, paddingVertical: 10, gap: 10,
  },
  titleBlock: { flex: 1, alignItems: "center" },
  animeTitleText: { color: "#fff", fontSize: 14, fontWeight: "700", textAlign: "center" },
  episodeTitleText: { color: "rgba(255,255,255,0.7)", fontSize: 11, textAlign: "center", marginTop: 2 },
  topRight: { flexDirection: "row", gap: 4 },
  iconBtn: {
    width: 38, height: 38, justifyContent: "center", alignItems: "center",
    borderRadius: 19, backgroundColor: "rgba(255,255,255,0.15)",
  },
  backArrow: { color: "#fff", fontSize: 20, fontWeight: "700" },
  iconBtnText: { color: "#fff", fontSize: 16 },

  // Center controls
  centerRow: {
    flexDirection: "row", justifyContent: "center",
    alignItems: "center", gap: 16, paddingHorizontal: 16,
  },
  epNavBtn: { alignItems: "center", gap: 3, padding: 8 },
  dimmed: { opacity: 0.3 },
  epNavIcon: { color: "#fff", fontSize: 22 },
  epNavLabel: { color: "rgba(255,255,255,0.6)", fontSize: 9 },
  seekCircle: { alignItems: "center", gap: 2, padding: 8 },
  seekCircleIcon: { color: "#fff", fontSize: 28 },
  seekCircleLabel: { color: "rgba(255,255,255,0.6)", fontSize: 9 },
  playCircle: {
    width: 68, height: 68, borderRadius: 34,
    backgroundColor: "rgba(229,57,53,0.85)",
    justifyContent: "center", alignItems: "center",
    shadowColor: "#E53935", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6, shadowRadius: 12, elevation: 8,
  },
  playCircleIcon: { color: "#fff", fontSize: 28 },

  // Bottom bar
  bottomBar: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 14, paddingTop: 6, gap: 6,
  },
  timeLabel: { color: "#fff", fontSize: 11, minWidth: 40, textAlign: "center" },
  progressWrapper: { flex: 1, height: 32, justifyContent: "center" },
  progressTouchArea: { flex: 1, justifyContent: "center" },
  progressTrack: {
    height: 4, backgroundColor: "rgba(255,255,255,0.3)",
    borderRadius: 2, overflow: "visible",
  },
  progressFill: { height: "100%", backgroundColor: "#E53935", borderRadius: 2 },
  progressThumb: {
    position: "absolute", top: -7, width: 18, height: 18,
    borderRadius: 9, backgroundColor: "#E53935", marginLeft: -9,
    shadowColor: "#E53935", shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 6, elevation: 6,
  },
  speedPill: {
    backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 4, minWidth: 38, alignItems: "center",
  },
  speedPillText: { color: "#fff", fontSize: 11, fontWeight: "700" },
  epListBtn: {
    width: 34, height: 34, justifyContent: "center", alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 8,
  },
  epListIcon: { color: "#fff", fontSize: 16 },

  // Episode counter badge
  epCounterBadge: {
    position: "absolute", top: 52, right: 14,
    backgroundColor: "rgba(0,0,0,0.55)", borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  epCounterText: { color: "rgba(255,255,255,0.8)", fontSize: 10 },

  // Info panel
  infoPanel: { flex: 1, backgroundColor: "#0D0D0D" },
  infoPanelContent: { padding: 16, gap: 8 },
  infoPanelTitle: { color: "#fff", fontSize: 15, fontWeight: "700" },
  infoPanelEpTitle: { color: "rgba(255,255,255,0.6)", fontSize: 12 },
  infoPanelSynopsis: { color: "#9BA1A6", fontSize: 12, lineHeight: 18, marginTop: 4 },

  // Quality selector
  qualitySection: { marginTop: 12 },
  qualitySectionTitle: { color: "#fff", fontSize: 13, fontWeight: "600", marginBottom: 8 },
  qualityRow: { flexDirection: "row", gap: 8 },
  qualityBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.2)",
    backgroundColor: "rgba(255,255,255,0.05)",
  },
  qualityBtnActive: { borderColor: "#E53935", backgroundColor: "rgba(229,57,53,0.15)" },
  qualityBtnText: { color: "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: "600" },
  qualityBtnTextActive: { color: "#E53935" },

  // Episode chips
  epChipsSection: { marginTop: 12 },
  epChipsSectionTitle: { color: "#fff", fontSize: 13, fontWeight: "600", marginBottom: 8 },
  epChipsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  epChip: {
    width: 44, height: 44, borderRadius: 10,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.15)",
    backgroundColor: "#1a1a2e", justifyContent: "center", alignItems: "center",
  },
  epChipActive: { borderColor: "#E53935", backgroundColor: "rgba(229,57,53,0.2)" },
  epChipText: { color: "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: "600" },
  epChipTextActive: { color: "#E53935", fontWeight: "800" },

  // Modals
  modalBackdrop: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.65)",
    justifyContent: "center", alignItems: "center",
  },
  speedMenu: {
    backgroundColor: "#1a1a2e", borderRadius: 20, padding: 20,
    minWidth: 230, gap: 2,
  },
  speedMenuTitle: {
    color: "#fff", fontSize: 16, fontWeight: "700",
    textAlign: "center", marginBottom: 12,
  },
  speedOption: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingVertical: 12, paddingHorizontal: 16, borderRadius: 12,
  },
  speedOptionActive: { backgroundColor: "rgba(229,57,53,0.15)" },
  speedOptionText: { color: "rgba(255,255,255,0.7)", fontSize: 15 },
  speedOptionTextActive: { color: "#E53935", fontWeight: "700" },
  checkMark: { color: "#E53935", fontSize: 16, fontWeight: "700" },

  // Episode list modal
  epListModal: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    backgroundColor: "#0f0f1a", borderTopLeftRadius: 24, borderTopRightRadius: 24,
    maxHeight: SCREEN_HEIGHT * 0.65, paddingBottom: 24,
  },
  epListModalHeader: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    padding: 20, borderBottomWidth: 1, borderBottomColor: "rgba(255,255,255,0.08)",
  },
  epListModalTitle: { color: "#fff", fontSize: 17, fontWeight: "700" },
  epListClose: { color: "rgba(255,255,255,0.5)", fontSize: 20, padding: 4 },
  epListItem: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingVertical: 14, gap: 14,
    borderBottomWidth: 1, borderBottomColor: "rgba(255,255,255,0.04)",
  },
  epListItemActive: { backgroundColor: "rgba(229,57,53,0.08)" },
  epListItemLeft: { width: 36, alignItems: "center", gap: 4 },
  epListItemNum: { color: "rgba(255,255,255,0.4)", fontSize: 14, fontWeight: "600" },
  epListItemNumActive: { color: "#E53935" },
  playingDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#E53935" },
  epListItemInfo: { flex: 1 },
  epListItemTitle: { color: "#fff", fontSize: 14, fontWeight: "500" },
  epListItemDuration: { color: "rgba(255,255,255,0.35)", fontSize: 11, marginTop: 2 },
  nowPlayingBadge: {
    backgroundColor: "rgba(229,57,53,0.15)", borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  nowPlayingText: { color: "#E53935", fontSize: 10, fontWeight: "700" },
  emptyText: { color: "rgba(255,255,255,0.3)", textAlign: "center", padding: 40, fontSize: 14 },
});

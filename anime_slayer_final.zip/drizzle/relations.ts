import { relations } from "drizzle-orm";
import { anime, animeGenres, episodes, genres } from "./schema";

export const animeRelations = relations(anime, ({ many }) => ({
  episodes: many(episodes),
  animeGenres: many(animeGenres),
}));

export const episodesRelations = relations(episodes, ({ one }) => ({
  anime: one(anime, {
    fields: [episodes.animeId],
    references: [anime.id],
  }),
}));

export const genresRelations = relations(genres, ({ many }) => ({
  animeGenres: many(animeGenres),
}));

export const animeGenresRelations = relations(animeGenres, ({ one }) => ({
  anime: one(anime, {
    fields: [animeGenres.animeId],
    references: [anime.id],
  }),
  genre: one(genres, {
    fields: [animeGenres.genreId],
    references: [genres.id],
  }),
}));

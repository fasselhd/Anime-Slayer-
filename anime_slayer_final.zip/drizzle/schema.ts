import {
  boolean,
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Anime / Movies table
 */
export const anime = mysqlTable("anime", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  titleAr: varchar("titleAr", { length: 255 }),
  synopsis: text("synopsis"),
  coverUrl: text("coverUrl"),
  bannerUrl: text("bannerUrl"),
  trailerUrl: text("trailerUrl"),
  type: mysqlEnum("type", ["series", "movie", "ova", "special"]).default("series").notNull(),
  status: mysqlEnum("status", ["ongoing", "completed", "upcoming"]).default("ongoing").notNull(),
  year: int("year"),
  season: mysqlEnum("season", ["winter", "spring", "summer", "fall"]),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("0.0"),
  views: int("views").default(0).notNull(),
  isFeatured: boolean("isFeatured").default(false).notNull(),
  isTrending: boolean("isTrending").default(false).notNull(),
  studio: varchar("studio", { length: 255 }),
  totalEpisodes: int("totalEpisodes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Anime = typeof anime.$inferSelect;
export type InsertAnime = typeof anime.$inferInsert;

/**
 * Genres table
 */
export const genres = mysqlTable("genres", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  nameAr: varchar("nameAr", { length: 100 }),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  color: varchar("color", { length: 7 }).default("#1A6DFF"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Genre = typeof genres.$inferSelect;
export type InsertGenre = typeof genres.$inferInsert;

/**
 * Anime-Genre relationship (many-to-many)
 */
export const animeGenres = mysqlTable("anime_genres", {
  id: int("id").autoincrement().primaryKey(),
  animeId: int("animeId").notNull(),
  genreId: int("genreId").notNull(),
});

export type AnimeGenre = typeof animeGenres.$inferSelect;

/**
 * Episodes table
 */
export const episodes = mysqlTable("episodes", {
  id: int("id").autoincrement().primaryKey(),
  animeId: int("animeId").notNull(),
  number: int("number").notNull(),
  title: varchar("title", { length: 255 }),
  titleAr: varchar("titleAr", { length: 255 }),
  synopsis: text("synopsis"),
  thumbnailUrl: text("thumbnailUrl"),
  videoUrl: text("videoUrl"),
  videoUrl480p: text("videoUrl480p"),
  videoUrl720p: text("videoUrl720p"),
  videoUrl1080p: text("videoUrl1080p"),
  duration: int("duration"), // in seconds
  views: int("views").default(0).notNull(),
  airDate: timestamp("airDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Episode = typeof episodes.$inferSelect;
export type InsertEpisode = typeof episodes.$inferInsert;

/**
 * App settings / admin config
 */
export const appSettings = mysqlTable("app_settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AppSetting = typeof appSettings.$inferSelect;

CREATE TABLE `anime` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`titleAr` varchar(255),
	`synopsis` text,
	`coverUrl` text,
	`bannerUrl` text,
	`trailerUrl` text,
	`type` enum('series','movie','ova','special') NOT NULL DEFAULT 'series',
	`status` enum('ongoing','completed','upcoming') NOT NULL DEFAULT 'ongoing',
	`year` int,
	`season` enum('winter','spring','summer','fall'),
	`rating` decimal(3,1) DEFAULT '0.0',
	`views` int NOT NULL DEFAULT 0,
	`isFeatured` boolean NOT NULL DEFAULT false,
	`isTrending` boolean NOT NULL DEFAULT false,
	`studio` varchar(255),
	`totalEpisodes` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `anime_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `anime_genres` (
	`id` int AUTO_INCREMENT NOT NULL,
	`animeId` int NOT NULL,
	`genreId` int NOT NULL,
	CONSTRAINT `anime_genres_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `app_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `app_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `app_settings_key_unique` UNIQUE(`key`)
);
--> statement-breakpoint
CREATE TABLE `episodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`animeId` int NOT NULL,
	`number` int NOT NULL,
	`title` varchar(255),
	`titleAr` varchar(255),
	`synopsis` text,
	`thumbnailUrl` text,
	`videoUrl` text,
	`videoUrl480p` text,
	`videoUrl720p` text,
	`videoUrl1080p` text,
	`duration` int,
	`views` int NOT NULL DEFAULT 0,
	`airDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `episodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `genres` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`nameAr` varchar(100),
	`slug` varchar(100) NOT NULL,
	`color` varchar(7) DEFAULT '#1A6DFF',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `genres_id` PRIMARY KEY(`id`),
	CONSTRAINT `genres_name_unique` UNIQUE(`name`),
	CONSTRAINT `genres_slug_unique` UNIQUE(`slug`)
);

/**
 * AdMob Banner Component - Native (iOS/Android) Implementation
 * This file is automatically used on native platforms by Metro bundler.
 */
import { View, StyleSheet } from "react-native";
import { BannerAd, BannerAdSize } from "react-native-google-mobile-ads";

const BANNER_AD_UNIT_ID = "ca-app-pub-7032269320751343/1591409450";

interface AdMobBannerProps {
  style?: object;
}

export function AdMobBanner({ style }: AdMobBannerProps) {
  return (
    <View style={[styles.container, style]}>
      <BannerAd
        unitId={BANNER_AD_UNIT_ID}
        size={BannerAdSize.BANNER}
        requestOptions={{
          requestNonPersonalizedAdsOnly: false,
        }}
        onAdLoaded={() => {}}
        onAdFailedToLoad={() => {}}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    minHeight: 50,
  },
});

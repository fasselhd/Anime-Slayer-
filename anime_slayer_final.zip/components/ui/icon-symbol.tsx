// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "magnifyingglass": "search",
  "heart.fill": "favorite",
  "heart": "favorite-border",
  "square.grid.2x2.fill": "grid-view",
  "gear": "settings",
  "play.fill": "play-arrow",
  "play.circle.fill": "play-circle-filled",
  "pause.fill": "pause",
  "backward.fill": "skip-previous",
  "forward.fill": "skip-next",
  "arrow.left": "arrow-back",
  "arrow.right": "arrow-forward",
  "star.fill": "star",
  "star": "star-border",
  "eye.fill": "visibility",
  "calendar": "calendar-today",
  "film": "movie",
  "tv": "tv",
  "list.bullet": "list",
  "plus": "add",
  "pencil": "edit",
  "trash": "delete",
  "xmark": "close",
  "checkmark": "check",
  "person.fill": "person",
  "lock.fill": "lock",
  "shield.fill": "admin-panel-settings",
  "chart.bar.fill": "bar-chart",
  "arrow.clockwise": "refresh",
  "ellipsis": "more-horiz",
  "square.and.arrow.up": "share",
  "bookmark.fill": "bookmark",
  "bookmark": "bookmark-border",
  "info.circle": "info",
  "exclamationmark.triangle": "warning",
  "sparkles": "auto-awesome",
  "flame.fill": "local-fire-department",
  "clock.fill": "access-time",
  "arrow.up.right": "open-in-new",
  "fullscreen": "fullscreen",
  "fullscreen.exit": "fullscreen-exit",
  "speaker.fill": "volume-up",
  "speaker.slash.fill": "volume-off",
} as unknown as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}

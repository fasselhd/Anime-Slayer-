import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { Dimensions, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/use-colors";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

interface HeroBannerItem {
  id: number;
  title: string;
  titleAr?: string | null;
  bannerUrl?: string | null;
  coverUrl?: string | null;
  synopsis?: string | null;
  type?: string;
  status?: string;
}

interface HeroBannerProps {
  items: HeroBannerItem[];
}

export function HeroBanner({ items }: HeroBannerProps) {
  const colors = useColors();
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    if (items.length <= 1) return;
    const interval = setInterval(() => {
      const nextIndex = (activeIndex + 1) % items.length;
      flatListRef.current?.scrollToIndex({ index: nextIndex, animated: true });
      setActiveIndex(nextIndex);
    }, 4000);
    return () => clearInterval(interval);
  }, [activeIndex, items.length]);

  if (items.length === 0) return null;

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={items}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id.toString()}
        onMomentumScrollEnd={(e) => {
          const index = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
          setActiveIndex(index);
        }}
        renderItem={({ item }) => (
          <Pressable
            style={({ pressed }) => [styles.slide, { opacity: pressed ? 0.9 : 1 }]}
            onPress={() => router.push(`/anime/${item.id}` as any)}
          >
            <Image
              source={{ uri: item.bannerUrl || item.coverUrl || "" }}
              style={StyleSheet.absoluteFill}
              contentFit="cover"
              transition={300}
            />
            <LinearGradient
              colors={["transparent", "rgba(13,13,13,0.7)", "#0D0D0D"]}
              style={styles.gradient}
            />
            <View style={styles.content}>
              <View style={styles.badges}>
                <View style={[styles.badge, { backgroundColor: colors.accent }]}>
                  <Text style={styles.badgeText}>
                    {item.type === "movie" ? "فيلم" : "مسلسل"}
                  </Text>
                </View>
                {item.status === "ongoing" && (
                  <View style={[styles.badge, { backgroundColor: colors.success }]}>
                    <Text style={styles.badgeText}>يعرض الآن</Text>
                  </View>
                )}
              </View>
              <Text style={styles.title} numberOfLines={2}>
                {item.titleAr || item.title}
              </Text>
              {item.synopsis && (
                <Text style={[styles.synopsis, { color: colors.muted }]} numberOfLines={2}>
                  {item.synopsis}
                </Text>
              )}
              <View style={[styles.watchBtn, { backgroundColor: colors.primary }]}>
                <Text style={styles.watchBtnText}>▶ شاهد الآن</Text>
              </View>
            </View>
          </Pressable>
        )}
      />
      {/* Dots */}
      {items.length > 1 && (
        <View style={styles.dots}>
          {items.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                { backgroundColor: i === activeIndex ? colors.primary : colors.border },
                i === activeIndex && styles.dotActive,
              ]}
            />
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 300,
  },
  slide: {
    width: SCREEN_WIDTH,
    height: 300,
  },
  gradient: {
    ...StyleSheet.absoluteFillObject,
  },
  content: {
    position: "absolute",
    bottom: 20,
    left: 16,
    right: 16,
  },
  badges: {
    flexDirection: "row",
    gap: 6,
    marginBottom: 8,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 4,
  },
  badgeText: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "700",
  },
  title: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "800",
    marginBottom: 6,
    textShadowColor: "rgba(0,0,0,0.8)",
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  synopsis: {
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 12,
  },
  watchBtn: {
    alignSelf: "flex-start",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  watchBtnText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
  },
  dots: {
    position: "absolute",
    bottom: 8,
    right: 16,
    flexDirection: "row",
    gap: 4,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  dotActive: {
    width: 18,
  },
});

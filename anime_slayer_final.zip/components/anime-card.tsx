import { Image } from "expo-image";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/use-colors";

interface AnimeCardProps {
  id: number;
  title: string;
  titleAr?: string | null;
  coverUrl?: string | null;
  type?: string;
  status?: string;
  rating?: string | null;
  year?: number | null;
  views?: number;
  compact?: boolean;
}

export function AnimeCard({
  id,
  title,
  titleAr,
  coverUrl,
  type,
  status,
  rating,
  year,
  views,
  compact = false,
}: AnimeCardProps) {
  const colors = useColors();

  const typeLabel = type === "movie" ? "فيلم" : type === "ova" ? "OVA" : type === "special" ? "خاص" : "مسلسل";
  const statusLabel = status === "ongoing" ? "يعرض" : status === "completed" ? "مكتمل" : "قادم";
  const statusColor = status === "ongoing" ? colors.success : status === "completed" ? colors.muted : colors.warning;

  return (
    <Pressable
      style={({ pressed }) => [
        styles.container,
        compact ? styles.compact : styles.normal,
        { opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={() => router.push(`/anime/${id}` as any)}
    >
      {/* Cover Image */}
      <View style={[styles.imageContainer, compact ? styles.compactImage : styles.normalImage]}>
        {coverUrl ? (
          <Image
            source={{ uri: coverUrl }}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            transition={200}
          />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.placeholder, { backgroundColor: colors.surface }]}>
            <Text style={[styles.placeholderText, { color: colors.muted }]}>🎌</Text>
          </View>
        )}
        {/* Type Badge */}
        <View style={[styles.typeBadge, { backgroundColor: type === "movie" ? colors.accent : colors.primary }]}>
          <Text style={styles.typeBadgeText}>{typeLabel}</Text>
        </View>
        {/* Rating */}
        {rating && parseFloat(rating) > 0 && (
          <View style={[styles.ratingBadge, { backgroundColor: "rgba(0,0,0,0.7)" }]}>
            <Text style={styles.ratingText}>⭐ {parseFloat(rating).toFixed(1)}</Text>
          </View>
        )}
      </View>

      {/* Info */}
      <View style={styles.info}>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>
          {titleAr || title}
        </Text>
        {!compact && (
          <View style={styles.meta}>
            {year && <Text style={[styles.metaText, { color: colors.muted }]}>{year}</Text>}
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.metaText, { color: statusColor }]}>{statusLabel}</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    overflow: "hidden",
  },
  normal: {
    width: 140,
  },
  compact: {
    width: 110,
  },
  imageContainer: {
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#1A1A2E",
  },
  normalImage: {
    height: 200,
  },
  compactImage: {
    height: 155,
  },
  placeholder: {
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    fontSize: 32,
  },
  typeBadge: {
    position: "absolute",
    top: 6,
    left: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  typeBadgeText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontWeight: "700",
  },
  ratingBadge: {
    position: "absolute",
    bottom: 6,
    right: 6,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 4,
  },
  ratingText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "600",
  },
  info: {
    paddingTop: 6,
    paddingHorizontal: 2,
  },
  title: {
    fontSize: 12,
    fontWeight: "600",
    lineHeight: 16,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
    gap: 4,
  },
  metaText: {
    fontSize: 10,
  },
  statusDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
});

/**
 * AdMob Banner Component
 * 
 * Uses platform-specific implementation:
 * - admob-banner.native.tsx for iOS/Android (real AdMob)
 * - admob-banner.tsx (this file) for web (placeholder)
 * 
 * Since Metro resolves .native.tsx before .tsx on native platforms,
 * this file only runs on web.
 */
import { View, StyleSheet, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";

interface AdMobBannerProps {
  style?: object;
}

export function AdMobBanner({ style }: AdMobBannerProps) {
  const colors = useColors();
  return (
    <View style={[styles.placeholder, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>
      <Text style={[styles.placeholderText, { color: colors.muted }]}>إعلان</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  placeholder: {
    height: 50,
    width: "100%",
    borderTopWidth: 0.5,
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    fontSize: 11,
  },
});

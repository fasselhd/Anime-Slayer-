import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Anime Routes ─────────────────────────────────────────────────────────
  anime: router({
    list: publicProcedure
      .input(
        z.object({
          type: z.enum(["series", "movie", "ova", "special"]).optional(),
          status: z.enum(["ongoing", "completed", "upcoming"]).optional(),
          limit: z.number().min(1).max(100).default(20),
          offset: z.number().min(0).default(0),
          search: z.string().optional(),
        }).optional()
      )
      .query(({ input }) => db.getAllAnime(input ?? {})),

    featured: publicProcedure.query(() => db.getFeaturedAnime()),

    trending: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(({ input }) => db.getTrendingAnime(input?.limit)),

    recent: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(({ input }) => db.getRecentAnime(input?.limit)),

    popularMovies: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(({ input }) => db.getPopularMovies(input?.limit)),

    byId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getAnimeById(input.id)),

    search: publicProcedure
      .input(z.object({ query: z.string().min(1), limit: z.number().default(20) }))
      .query(({ input }) => db.searchAnime(input.query, input.limit)),

    incrementViews: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.incrementAnimeViews(input.id)),

    // Admin operations
    create: publicProcedure
      .input(
        z.object({
          title: z.string().min(1).max(255),
          titleAr: z.string().max(255).optional(),
          synopsis: z.string().optional(),
          coverUrl: z.string().optional(),
          bannerUrl: z.string().optional(),
          trailerUrl: z.string().optional(),
          type: z.enum(["series", "movie", "ova", "special"]).default("series"),
          status: z.enum(["ongoing", "completed", "upcoming"]).default("ongoing"),
          year: z.number().optional(),
          season: z.enum(["winter", "spring", "summer", "fall"]).optional(),
          rating: z.string().optional(),
          isFeatured: z.boolean().default(false),
          isTrending: z.boolean().default(false),
          studio: z.string().optional(),
          totalEpisodes: z.number().optional(),
          genreIds: z.array(z.number()).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { genreIds, ...animeData } = input;
        const id = await db.createAnime(animeData as any);
        if (genreIds && genreIds.length > 0) {
          await db.setAnimeGenres(Number(id), genreIds);
        }
        return { id };
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(1).max(255).optional(),
          titleAr: z.string().max(255).optional(),
          synopsis: z.string().optional(),
          coverUrl: z.string().optional(),
          bannerUrl: z.string().optional(),
          trailerUrl: z.string().optional(),
          type: z.enum(["series", "movie", "ova", "special"]).optional(),
          status: z.enum(["ongoing", "completed", "upcoming"]).optional(),
          year: z.number().optional(),
          season: z.enum(["winter", "spring", "summer", "fall"]).optional(),
          rating: z.string().optional(),
          isFeatured: z.boolean().optional(),
          isTrending: z.boolean().optional(),
          studio: z.string().optional(),
          totalEpisodes: z.number().optional(),
          genreIds: z.array(z.number()).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, genreIds, ...data } = input;
        await db.updateAnime(id, data as any);
        if (genreIds !== undefined) {
          await db.setAnimeGenres(id, genreIds);
        }
        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteAnime(input.id)),
  }),

  // ─── Episode Routes ────────────────────────────────────────────────────────
  episodes: router({
    byAnimeId: publicProcedure
      .input(z.object({ animeId: z.number() }))
      .query(({ input }) => db.getEpisodesByAnimeId(input.animeId)),

    byId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getEpisodeById(input.id)),

    incrementViews: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.incrementEpisodeViews(input.id)),

    create: publicProcedure
      .input(
        z.object({
          animeId: z.number(),
          number: z.number(),
          title: z.string().max(255).optional(),
          titleAr: z.string().max(255).optional(),
          synopsis: z.string().optional(),
          thumbnailUrl: z.string().optional(),
          videoUrl: z.string().optional(),
          videoUrl480p: z.string().optional(),
          videoUrl720p: z.string().optional(),
          videoUrl1080p: z.string().optional(),
          duration: z.number().optional(),
        })
      )
      .mutation(({ input }) => db.createEpisode(input as any)),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          number: z.number().optional(),
          title: z.string().max(255).optional(),
          titleAr: z.string().max(255).optional(),
          synopsis: z.string().optional(),
          thumbnailUrl: z.string().optional(),
          videoUrl: z.string().optional(),
          videoUrl480p: z.string().optional(),
          videoUrl720p: z.string().optional(),
          videoUrl1080p: z.string().optional(),
          duration: z.number().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateEpisode(id, data as any);
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteEpisode(input.id)),
  }),

  // ─── Genre Routes ──────────────────────────────────────────────────────────
  genres: router({
    list: publicProcedure.query(() => db.getAllGenres()),

    animeGenres: publicProcedure
      .input(z.object({ animeId: z.number() }))
      .query(({ input }) => db.getAnimeGenres(input.animeId)),

    create: publicProcedure
      .input(
        z.object({
          name: z.string().min(1).max(100),
          nameAr: z.string().max(100).optional(),
          slug: z.string().min(1).max(100),
          color: z.string().max(7).optional(),
        })
      )
      .mutation(({ input }) => db.createGenre(input as any)),

    seed: publicProcedure.mutation(() => db.seedDefaultGenres()),
  }),

  // ─── Statistics Routes ─────────────────────────────────────────────────────
  stats: router({
    overview: publicProcedure.query(() => db.getStats()),
  }),

  // ─── Settings Routes ───────────────────────────────────────────────────────
  settings: router({
    get: publicProcedure
      .input(z.object({ key: z.string() }))
      .query(({ input }) => db.getSetting(input.key)),

    set: publicProcedure
      .input(z.object({ key: z.string(), value: z.string() }))
      .mutation(({ input }) => db.setSetting(input.key, input.value)),
  }),
});

export type AppRouter = typeof appRouter;

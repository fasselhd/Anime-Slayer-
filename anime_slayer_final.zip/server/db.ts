import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

// ─── Anime Queries ───────────────────────────────────────────────────────────
import { and, desc, like, or, sql } from "drizzle-orm";
import {
  anime,
  animeGenres,
  appSettings,
  episodes,
  genres,
  type InsertAnime,
  type InsertEpisode,
  type InsertGenre,
} from "../drizzle/schema";

export async function getAllAnime(options?: {
  type?: "series" | "movie" | "ova" | "special";
  status?: "ongoing" | "completed" | "upcoming";
  limit?: number;
  offset?: number;
  search?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];
  if (options?.type) conditions.push(eq(anime.type, options.type));
  if (options?.status) conditions.push(eq(anime.status, options.status));
  if (options?.search) {
    conditions.push(
      or(
        like(anime.title, `%${options.search}%`),
        like(anime.titleAr, `%${options.search}%`)
      )
    );
  }

  const baseQuery = db.select().from(anime);
  if (conditions.length > 0) {
    return baseQuery
      .where(and(...conditions))
      .orderBy(desc(anime.createdAt))
      .limit(options?.limit ?? 50)
      .offset(options?.offset ?? 0);
  }
  return baseQuery
    .orderBy(desc(anime.createdAt))
    .limit(options?.limit ?? 50)
    .offset(options?.offset ?? 0);
}

export async function getFeaturedAnime() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(anime).where(eq(anime.isFeatured, true)).limit(5);
}

export async function getTrendingAnime(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(anime)
    .where(eq(anime.isTrending, true))
    .orderBy(desc(anime.views))
    .limit(limit);
}

export async function getRecentAnime(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(anime).orderBy(desc(anime.createdAt)).limit(limit);
}

export async function getPopularMovies(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(anime)
    .where(eq(anime.type, "movie"))
    .orderBy(desc(anime.views))
    .limit(limit);
}

export async function getAnimeById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(anime).where(eq(anime.id, id)).limit(1);
  return result[0] ?? null;
}

export async function searchAnime(query: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(anime)
    .where(
      or(
        like(anime.title, `%${query}%`),
        like(anime.titleAr, `%${query}%`)
      )
    )
    .limit(limit);
}

export async function createAnime(data: InsertAnime) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(anime).values(data);
  return result[0].insertId;
}

export async function updateAnime(id: number, data: Partial<InsertAnime>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(anime).set(data).where(eq(anime.id, id));
}

export async function deleteAnime(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(episodes).where(eq(episodes.animeId, id));
  await db.delete(animeGenres).where(eq(animeGenres.animeId, id));
  await db.delete(anime).where(eq(anime.id, id));
}

export async function incrementAnimeViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(anime)
    .set({ views: sql`${anime.views} + 1` })
    .where(eq(anime.id, id));
}

// ─── Episode Queries ─────────────────────────────────────────────────────────

export async function getEpisodesByAnimeId(animeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(episodes)
    .where(eq(episodes.animeId, animeId))
    .orderBy(episodes.number);
}

export async function getEpisodeById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(episodes).where(eq(episodes.id, id)).limit(1);
  return result[0] ?? null;
}

export async function createEpisode(data: InsertEpisode) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(episodes).values(data);
  return result[0].insertId;
}

export async function updateEpisode(id: number, data: Partial<InsertEpisode>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(episodes).set(data).where(eq(episodes.id, id));
}

export async function deleteEpisode(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(episodes).where(eq(episodes.id, id));
}

export async function incrementEpisodeViews(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(episodes)
    .set({ views: sql`${episodes.views} + 1` })
    .where(eq(episodes.id, id));
}

// ─── Genre Queries ────────────────────────────────────────────────────────────

export async function getAllGenres() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(genres);
}

export async function createGenre(data: InsertGenre) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(genres).values(data);
  return result[0].insertId;
}

export async function getAnimeGenres(animeId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ genre: genres })
    .from(animeGenres)
    .innerJoin(genres, eq(animeGenres.genreId, genres.id))
    .where(eq(animeGenres.animeId, animeId));
}

export async function setAnimeGenres(animeId: number, genreIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(animeGenres).where(eq(animeGenres.animeId, animeId));
  if (genreIds.length > 0) {
    await db.insert(animeGenres).values(
      genreIds.map((genreId) => ({ animeId, genreId }))
    );
  }
}

// ─── Statistics Queries ───────────────────────────────────────────────────────

export async function getStats() {
  const db = await getDb();
  if (!db) return { totalAnime: 0, totalMovies: 0, totalEpisodes: 0, totalViews: 0 };

  const [animeCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(anime)
    .where(eq(anime.type, "series"));

  const [movieCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(anime)
    .where(eq(anime.type, "movie"));

  const [episodeCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(episodes);

  const [viewsSum] = await db
    .select({ total: sql<number>`sum(${anime.views})` })
    .from(anime);

  return {
    totalAnime: Number(animeCount?.count ?? 0),
    totalMovies: Number(movieCount?.count ?? 0),
    totalEpisodes: Number(episodeCount?.count ?? 0),
    totalViews: Number(viewsSum?.total ?? 0),
  };
}

// ─── App Settings ─────────────────────────────────────────────────────────────

export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(appSettings)
    .where(eq(appSettings.key, key))
    .limit(1);
  return result[0]?.value ?? null;
}

export async function setSetting(key: string, value: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .insert(appSettings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}

// ─── Seed Default Genres ──────────────────────────────────────────────────────

export async function seedDefaultGenres() {
  const db = await getDb();
  if (!db) return;

  const defaultGenres: InsertGenre[] = [
    { name: "Action", nameAr: "أكشن", slug: "action", color: "#E94560" },
    { name: "Adventure", nameAr: "مغامرات", slug: "adventure", color: "#F59E0B" },
    { name: "Comedy", nameAr: "كوميدي", slug: "comedy", color: "#22C55E" },
    { name: "Drama", nameAr: "دراما", slug: "drama", color: "#8B5CF6" },
    { name: "Fantasy", nameAr: "فانتازيا", slug: "fantasy", color: "#1A6DFF" },
    { name: "Horror", nameAr: "رعب", slug: "horror", color: "#DC2626" },
    { name: "Mystery", nameAr: "غموض", slug: "mystery", color: "#6366F1" },
    { name: "Romance", nameAr: "رومانسي", slug: "romance", color: "#EC4899" },
    { name: "Sci-Fi", nameAr: "خيال علمي", slug: "sci-fi", color: "#06B6D4" },
    { name: "Slice of Life", nameAr: "حياة يومية", slug: "slice-of-life", color: "#84CC16" },
    { name: "Sports", nameAr: "رياضة", slug: "sports", color: "#F97316" },
    { name: "Supernatural", nameAr: "خارق للطبيعة", slug: "supernatural", color: "#7C3AED" },
    { name: "Thriller", nameAr: "إثارة", slug: "thriller", color: "#B45309" },
    { name: "Mecha", nameAr: "ميكا", slug: "mecha", color: "#64748B" },
    { name: "Isekai", nameAr: "إيسيكاي", slug: "isekai", color: "#0EA5E9" },
  ];

  for (const genre of defaultGenres) {
    try {
      await db.insert(genres).values(genre).onDuplicateKeyUpdate({ set: { nameAr: genre.nameAr } });
    } catch {
      // Ignore duplicates
    }
  }
}

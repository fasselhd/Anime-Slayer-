// Web shim for react-native-google-mobile-ads
// This module is used on web platform where AdMob is not available
module.exports = {
  BannerAd: null,
  BannerAdSize: { BANNER: 'BANNER', LARGE_BANNER: 'LARGE_BANNER' },
  InterstitialAd: null,
  RewardedAd: null,
  TestIds: {},
  default: null,
};

import AsyncStorage from "@react-native-async-storage/async-storage";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

const FAVORITES_KEY = "anime_favorites";

export interface FavoriteAnime {
  id: number;
  title: string;
  titleAr?: string | null;
  coverUrl?: string | null;
  type?: string;
  status?: string;
  rating?: string | null;
  year?: number | null;
  addedAt: number;
}

export async function getFavorites(): Promise<FavoriteAnime[]> {
  try {
    const data = await AsyncStorage.getItem(FAVORITES_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export async function addFavorite(anime: Omit<FavoriteAnime, "addedAt">): Promise<void> {
  const favorites = await getFavorites();
  const exists = favorites.find((f) => f.id === anime.id);
  if (!exists) {
    favorites.unshift({ ...anime, addedAt: Date.now() });
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  }
}

export async function removeFavorite(id: number): Promise<void> {
  const favorites = await getFavorites();
  const updated = favorites.filter((f) => f.id !== id);
  await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
}

export async function isFavorite(id: number): Promise<boolean> {
  const favorites = await getFavorites();
  return favorites.some((f) => f.id === id);
}

function FavoriteItem({ item, onRemove }: { item: FavoriteAnime; onRemove: (id: number) => void }) {
  const colors = useColors();
  const typeLabel = item.type === "movie" ? "فيلم" : item.type === "ova" ? "OVA" : "مسلسل";

  return (
    <Pressable
      style={({ pressed }) => [
        styles.favoriteItem,
        { backgroundColor: colors.surface, opacity: pressed ? 0.85 : 1 },
      ]}
      onPress={() => router.push(`/anime/${item.id}` as any)}
    >
      <View style={styles.coverContainer}>
        {item.coverUrl ? (
          <Image source={{ uri: item.coverUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.noCover, { backgroundColor: colors.surface2 }]}>
            <Text style={{ fontSize: 28 }}>🎌</Text>
          </View>
        )}
      </View>
      <View style={styles.itemInfo}>
        <Text style={[styles.itemTitle, { color: colors.foreground }]} numberOfLines={2}>
          {item.titleAr || item.title}
        </Text>
        <View style={styles.itemMeta}>
          <View style={[styles.typeBadge, { backgroundColor: item.type === "movie" ? colors.accent : colors.primary }]}>
            <Text style={styles.typeBadgeText}>{typeLabel}</Text>
          </View>
          {item.year && <Text style={[styles.metaText, { color: colors.muted }]}>{item.year}</Text>}
          {item.rating && parseFloat(item.rating) > 0 && (
            <Text style={[styles.metaText, { color: "#F59E0B" }]}>⭐ {parseFloat(item.rating).toFixed(1)}</Text>
          )}
        </View>
      </View>
      <Pressable
        style={({ pressed }) => [styles.removeBtn, { opacity: pressed ? 0.6 : 1 }]}
        onPress={() => onRemove(item.id)}
        hitSlop={8}
      >
        <IconSymbol name="heart.fill" size={22} color={colors.accent} />
      </Pressable>
    </Pressable>
  );
}

export default function FavoritesScreen() {
  const colors = useColors();
  useInterstitialAd();  // Show interstitial ad when screen opens
  const [favorites, setFavorites] = useState<FavoriteAnime[]>([]);

  useFocusEffect(
    useCallback(() => {
      getFavorites().then(setFavorites);
    }, [])
  );

  const handleRemove = async (id: number) => {
    await removeFavorite(id);
    setFavorites((prev) => prev.filter((f) => f.id !== id));
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>المفضلة</Text>
        <Text style={[styles.headerCount, { color: colors.muted }]}>{favorites.length} أنمي</Text>
      </View>

      <FlatList
        data={favorites}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => <FavoriteItem item={item} onRemove={handleRemove} />}

        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>💔</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>لا توجد مفضلة</Text>
            <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
              أضف الأنمي المفضل لديك من صفحة التفاصيل
            </Text>
            <Pressable
              style={[styles.browseBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push("/browse" as any)}
            >
              <Text style={styles.browseBtnText}>تصفح الأنمي</Text>
            </Pressable>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  headerCount: {
    fontSize: 13,
  },
  list: {
    padding: 16,
    gap: 10,
  },
  favoriteItem: {
    flexDirection: "row",
    borderRadius: 14,
    overflow: "hidden",
    marginBottom: 10,
    alignItems: "center",
  },
  coverContainer: {
    width: 75,
    height: 105,
    backgroundColor: "#1A1A2E",
  },
  noCover: {
    justifyContent: "center",
    alignItems: "center",
  },
  itemInfo: {
    flex: 1,
    padding: 12,
    gap: 6,
  },
  itemTitle: {
    fontSize: 14,
    fontWeight: "700",
    lineHeight: 20,
  },
  itemMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  typeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  typeBadgeText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "700",
  },
  metaText: {
    fontSize: 11,
  },
  removeBtn: {
    padding: 12,
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 80,
    gap: 10,
  },
  emptyEmoji: {
    fontSize: 56,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  emptySubtitle: {
    fontSize: 13,
    textAlign: "center",
    paddingHorizontal: 32,
  },
  browseBtn: {
    marginTop: 8,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
  },
  browseBtnText: {
    color: "#FFF",
    fontSize: 14,
    fontWeight: "700",
  },
});

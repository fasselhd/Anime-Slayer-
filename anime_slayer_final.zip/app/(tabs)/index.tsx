import { FlatList, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AnimeCard } from "@/components/anime-card";
import { HeroBanner } from "@/components/hero-banner";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { Image } from "expo-image";
import { useState } from "react";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeader}>
      <View style={[styles.sectionAccent, { backgroundColor: colors.primary }]} />
      <View>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
        {subtitle && <Text style={[styles.sectionSubtitle, { color: colors.muted }]}>{subtitle}</Text>}
      </View>
    </View>
  );
}

function LoadingRow() {
  const colors = useColors();
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}>
      {[1, 2, 3, 4].map((i) => (
        <View key={i} style={[styles.skeleton, { backgroundColor: colors.surface }]} />
      ))}
    </ScrollView>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const [refreshing, setRefreshing] = useState(false);
  useInterstitialAd();  // Show interstitial ad when screen opens

  const { data: featured, refetch: refetchFeatured } = trpc.anime.featured.useQuery();
  const { data: trending, refetch: refetchTrending } = trpc.anime.trending.useQuery({ limit: 10 });
  const { data: recent, refetch: refetchRecent } = trpc.anime.recent.useQuery({ limit: 10 });
  const { data: movies, refetch: refetchMovies } = trpc.anime.popularMovies.useQuery({ limit: 10 });

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchFeatured(), refetchTrending(), refetchRecent(), refetchMovies()]);
    setRefreshing(false);
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={colors.primary}
          />
        }
      >
        {/* App Header */}
        <View style={[styles.header, { backgroundColor: colors.background }]}>
          <View style={styles.headerLeft}>
            <Image
              source={require("@/assets/images/icon.png")}
              style={styles.logo}
              contentFit="contain"
            />
            <Text style={[styles.appName, { color: colors.foreground }]}>أنمي سلاير</Text>
          </View>
          <Text style={[styles.headerTagline, { color: colors.muted }]}>شاهد الأنمي مجاناً</Text>
        </View>

        {/* Hero Banner */}
        {featured && featured.length > 0 ? (
          <HeroBanner items={featured} />
        ) : (
          <View style={[styles.heroBannerPlaceholder, { backgroundColor: colors.surface }]}>
            <Text style={[styles.placeholderText, { color: colors.muted }]}>
              لا توجد أنمي مميزة بعد
            </Text>
          </View>
        )}

        <View style={styles.content}>
          {/* Trending Section */}
          <View style={styles.section}>
            <SectionHeader title="🔥 الأكثر مشاهدة" subtitle="الأنمي الرائج الآن" />
            {trending ? (
              <FlatList
                data={trending}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                  <AnimeCard
                    id={item.id}
                    title={item.title}
                    titleAr={item.titleAr}
                    coverUrl={item.coverUrl}
                    type={item.type}
                    status={item.status}
                    rating={item.rating}
                    year={item.year}
                  />
                )}
                ListEmptyComponent={
                  <Text style={[styles.emptyText, { color: colors.muted }]}>لا توجد أنمي رائجة بعد</Text>
                }
              />
            ) : (
              <LoadingRow />
            )}
          </View>

          {/* Recently Added Section */}
          <View style={styles.section}>
            <SectionHeader title="🆕 أضيف حديثاً" subtitle="آخر الإضافات" />
            {recent ? (
              <FlatList
                data={recent}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                  <AnimeCard
                    id={item.id}
                    title={item.title}
                    titleAr={item.titleAr}
                    coverUrl={item.coverUrl}
                    type={item.type}
                    status={item.status}
                    rating={item.rating}
                    year={item.year}
                  />
                )}
                ListEmptyComponent={
                  <Text style={[styles.emptyText, { color: colors.muted }]}>لا توجد إضافات حديثة</Text>
                }
              />
            ) : (
              <LoadingRow />
            )}
          </View>

          {/* Popular Movies Section */}
          <View style={styles.section}>
            <SectionHeader title="🎬 أفلام الأنمي" subtitle="أشهر أفلام الأنمي" />
            {movies ? (
              <FlatList
                data={movies}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                  <AnimeCard
                    id={item.id}
                    title={item.title}
                    titleAr={item.titleAr}
                    coverUrl={item.coverUrl}
                    type={item.type}
                    status={item.status}
                    rating={item.rating}
                    year={item.year}
                  />
                )}
                ListEmptyComponent={
                  <Text style={[styles.emptyText, { color: colors.muted }]}>لا توجد أفلام بعد</Text>
                }
              />
            ) : (
              <LoadingRow />
            )}
          </View>

          {/* Bottom padding */}
          <View style={{ height: 20 }} />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  logo: {
    width: 32,
    height: 32,
    borderRadius: 8,
  },
  appName: {
    fontSize: 20,
    fontWeight: "800",
  },
  headerTagline: {
    fontSize: 12,
  },
  heroBannerPlaceholder: {
    height: 200,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 16,
    borderRadius: 16,
  },
  placeholderText: {
    fontSize: 14,
  },
  content: {
    paddingTop: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionAccent: {
    width: 4,
    height: 20,
    borderRadius: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  sectionSubtitle: {
    fontSize: 11,
    marginTop: 1,
  },
  horizontalList: {
    paddingHorizontal: 16,
    gap: 12,
  },
  skeleton: {
    width: 140,
    height: 200,
    borderRadius: 10,
  },
  emptyText: {
    fontSize: 13,
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
});

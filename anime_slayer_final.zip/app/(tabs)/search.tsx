import { Image } from "expo-image";
import { router } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

function SearchResultItem({ item }: { item: any }) {
  const colors = useColors();
  const typeLabel = item.type === "movie" ? "فيلم" : item.type === "ova" ? "OVA" : "مسلسل";

  return (
    <Pressable
      style={({ pressed }) => [
        styles.resultItem,
        { backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={() => router.push(`/anime/${item.id}` as any)}
    >
      <View style={styles.resultCover}>
        {item.coverUrl ? (
          <Image source={{ uri: item.coverUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.noCover, { backgroundColor: colors.surface2 }]}>
            <Text style={{ fontSize: 24 }}>🎌</Text>
          </View>
        )}
      </View>
      <View style={styles.resultInfo}>
        <Text style={[styles.resultTitle, { color: colors.foreground }]} numberOfLines={2}>
          {item.titleAr || item.title}
        </Text>
        {item.title !== item.titleAr && item.titleAr && (
          <Text style={[styles.resultTitleEn, { color: colors.muted }]} numberOfLines={1}>
            {item.title}
          </Text>
        )}
        <View style={styles.resultMeta}>
          <View style={[styles.typeBadge, { backgroundColor: item.type === "movie" ? colors.accent : colors.primary }]}>
            <Text style={styles.typeBadgeText}>{typeLabel}</Text>
          </View>
          {item.year && <Text style={[styles.metaText, { color: colors.muted }]}>{item.year}</Text>}
          {item.rating && parseFloat(item.rating) > 0 && (
            <Text style={[styles.metaText, { color: "#F59E0B" }]}>⭐ {parseFloat(item.rating).toFixed(1)}</Text>
          )}
        </View>
        {item.synopsis && (
          <Text style={[styles.synopsis, { color: colors.muted }]} numberOfLines={2}>
            {item.synopsis}
          </Text>
        )}
      </View>
    </Pressable>
  );
}

export default function SearchScreen() {
  const colors = useColors();
  useInterstitialAd();  // Show interstitial ad when screen opens
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const inputRef = useRef<TextInput>(null);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 400);
    return () => clearTimeout(timer);
  }, [query]);

  const { data: results, isLoading } = trpc.anime.search.useQuery(
    { query: debouncedQuery, limit: 30 },
    { enabled: debouncedQuery.length >= 2 }
  );

  const { data: trending } = trpc.anime.trending.useQuery({ limit: 8 });

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      {/* Search Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>البحث</Text>
        <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
          <TextInput
            ref={inputRef}
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="ابحث عن أنمي، فيلم، أو مسلسل..."
            placeholderTextColor={colors.muted}
            value={query}
            onChangeText={setQuery}
            returnKeyType="search"
            autoCorrect={false}
            textAlign="right"
          />
          {query.length > 0 && (
            <Pressable onPress={() => setQuery("")} style={{ padding: 4 }}>
              <IconSymbol name="xmark" size={14} color={colors.muted} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Content */}
      {query.length < 2 ? (
        /* Trending suggestions */
        <FlatList
          data={trending}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.suggestionsContainer}
          ListHeaderComponent={
            <Text style={[styles.suggestionsTitle, { color: colors.muted }]}>🔥 الأكثر مشاهدة</Text>
          }
          renderItem={({ item }) => (
            <Pressable
              style={({ pressed }) => [
                styles.suggestionItem,
                { backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 },
              ]}
              onPress={() => router.push(`/anime/${item.id}` as any)}
            >
              <View style={[styles.suggestionIcon, { backgroundColor: colors.surface2 }]}>
                <Text style={{ fontSize: 16 }}>🎌</Text>
              </View>
              <Text style={[styles.suggestionText, { color: colors.foreground }]} numberOfLines={1}>
                {item.titleAr || item.title}
              </Text>
              <IconSymbol name="chevron.right" size={16} color={colors.muted} />
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyEmoji}>🔍</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>ابحث عن أنمي</Text>
              <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
                اكتب اسم الأنمي أو الفيلم للبحث
              </Text>
            </View>
          }
        />
      ) : isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.muted }]}>جاري البحث...</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.resultsList}
          ListHeaderComponent={
            <Text style={[styles.resultsCount, { color: colors.muted }]}>
              {results?.length ?? 0} نتيجة لـ "{debouncedQuery}"
            </Text>
          }
          renderItem={({ item }) => <SearchResultItem item={item} />}

          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyEmoji}>😕</Text>
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>لا توجد نتائج</Text>
              <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
                لم يتم العثور على "{debouncedQuery}"
              </Text>
            </View>
          }
        />
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
    borderBottomWidth: 0.5,
    gap: 10,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
  },
  suggestionsContainer: {
    padding: 16,
    gap: 8,
  },
  suggestionsTitle: {
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 8,
  },
  suggestionItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    gap: 12,
    marginBottom: 6,
  },
  suggestionIcon: {
    width: 36,
    height: 36,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  suggestionText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
  },
  resultsList: {
    padding: 16,
    gap: 10,
  },
  resultsCount: {
    fontSize: 12,
    marginBottom: 8,
  },
  resultItem: {
    flexDirection: "row",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 10,
  },
  resultCover: {
    width: 80,
    height: 110,
    backgroundColor: "#1A1A2E",
  },
  noCover: {
    justifyContent: "center",
    alignItems: "center",
  },
  resultInfo: {
    flex: 1,
    padding: 10,
    gap: 4,
  },
  resultTitle: {
    fontSize: 14,
    fontWeight: "700",
    lineHeight: 20,
  },
  resultTitleEn: {
    fontSize: 11,
  },
  resultMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    flexWrap: "wrap",
  },
  typeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  typeBadgeText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "700",
  },
  metaText: {
    fontSize: 11,
  },
  synopsis: {
    fontSize: 11,
    lineHeight: 16,
    marginTop: 4,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 60,
    gap: 8,
  },
  emptyEmoji: {
    fontSize: 48,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  emptySubtitle: {
    fontSize: 13,
    textAlign: "center",
  },
});

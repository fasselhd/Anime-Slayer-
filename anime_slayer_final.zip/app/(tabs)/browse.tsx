import { FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AnimeCard } from "@/components/anime-card";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

const TYPE_FILTERS = [
  { label: "الكل", value: undefined },
  { label: "مسلسلات", value: "series" as const },
  { label: "أفلام", value: "movie" as const },
  { label: "OVA", value: "ova" as const },
];

const STATUS_FILTERS = [
  { label: "الكل", value: undefined },
  { label: "يعرض", value: "ongoing" as const },
  { label: "مكتمل", value: "completed" as const },
  { label: "قادم", value: "upcoming" as const },
];

export default function BrowseScreen() {
  const colors = useColors();
  useInterstitialAd();  // Show interstitial ad when screen opens
  const [typeFilter, setTypeFilter] = useState<"series" | "movie" | "ova" | "special" | undefined>(undefined);
  const [statusFilter, setStatusFilter] = useState<"ongoing" | "completed" | "upcoming" | undefined>(undefined);
  const [searchText, setSearchText] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const { data: animeList, refetch, isLoading } = trpc.anime.list.useQuery({
    type: typeFilter,
    status: statusFilter,
    limit: 50,
    offset: 0,
    search: searchText.length >= 2 ? searchText : undefined,
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>تصفح الأنمي</Text>
        {/* Search */}
        <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="magnifyingglass" size={16} color={colors.muted} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="ابحث عن أنمي..."
            placeholderTextColor={colors.muted}
            value={searchText}
            onChangeText={setSearchText}
            returnKeyType="search"
          />
          {searchText.length > 0 && (
            <Pressable onPress={() => setSearchText("")}>
              <IconSymbol name="xmark" size={14} color={colors.muted} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Filters */}
      <View style={[styles.filtersContainer, { borderBottomColor: colors.border }]}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
          {TYPE_FILTERS.map((f) => (
            <Pressable
              key={f.label}
              style={[
                styles.filterChip,
                {
                  backgroundColor: typeFilter === f.value ? colors.primary : colors.surface,
                  borderColor: typeFilter === f.value ? colors.primary : colors.border,
                },
              ]}
              onPress={() => setTypeFilter(f.value)}
            >
              <Text style={[styles.filterChipText, { color: typeFilter === f.value ? "#FFF" : colors.muted }]}>
                {f.label}
              </Text>
            </Pressable>
          ))}
          <View style={[styles.filterDivider, { backgroundColor: colors.border }]} />
          {STATUS_FILTERS.map((f) => (
            <Pressable
              key={f.label}
              style={[
                styles.filterChip,
                {
                  backgroundColor: statusFilter === f.value ? colors.accent : colors.surface,
                  borderColor: statusFilter === f.value ? colors.accent : colors.border,
                },
              ]}
              onPress={() => setStatusFilter(f.value)}
            >
              <Text style={[styles.filterChipText, { color: statusFilter === f.value ? "#FFF" : colors.muted }]}>
                {f.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {/* Results Count */}
      <View style={styles.resultsInfo}>
        <Text style={[styles.resultsText, { color: colors.muted }]}>
          {isLoading ? "جاري التحميل..." : `${animeList?.length ?? 0} نتيجة`}
        </Text>
      </View>

      {/* Grid */}
      <FlatList
        data={animeList}
        numColumns={3}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.row}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />
        }
        renderItem={({ item }) => (
          <AnimeCard
            id={item.id}
            title={item.title}
            titleAr={item.titleAr}
            coverUrl={item.coverUrl}
            type={item.type}
            status={item.status}
            rating={item.rating}
            year={item.year}
            compact
          />
        )}

        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>🎌</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {isLoading ? "جاري التحميل..." : "لا توجد نتائج"}
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.muted }]}>
              {isLoading ? "" : "جرب تغيير الفلاتر أو البحث بكلمة أخرى"}
            </Text>
          </View>
        }
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
    borderBottomWidth: 0.5,
    gap: 10,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    textAlign: "right",
  },
  filtersContainer: {
    borderBottomWidth: 0.5,
    paddingVertical: 10,
  },
  filterRow: {
    paddingHorizontal: 16,
    gap: 8,
    alignItems: "center",
  },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterChipText: {
    fontSize: 12,
    fontWeight: "600",
  },
  filterDivider: {
    width: 1,
    height: 20,
    marginHorizontal: 4,
  },
  resultsInfo: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  resultsText: {
    fontSize: 12,
  },
  grid: {
    paddingHorizontal: 12,
    paddingBottom: 20,
  },
  row: {
    gap: 8,
    marginBottom: 8,
    justifyContent: "flex-start",
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 60,
    gap: 8,
  },
  emptyEmoji: {
    fontSize: 48,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  emptySubtitle: {
    fontSize: 13,
    textAlign: "center",
  },
});

import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { trpc } from "@/lib/trpc";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

function MenuRow({ icon, label, subtitle, onPress, danger }: {
  icon: any;
  label: string;
  subtitle?: string;
  onPress?: () => void;
  danger?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.menuRow,
        { backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={onPress}
    >
      <View style={[styles.menuIcon, { backgroundColor: danger ? colors.error + "22" : colors.primary + "22" }]}>
        <IconSymbol name={icon} size={18} color={danger ? colors.error : colors.primary} />
      </View>
      <View style={styles.menuInfo}>
        <Text style={[styles.menuLabel, { color: danger ? colors.error : colors.foreground }]}>{label}</Text>
        {subtitle && <Text style={[styles.menuSubtitle, { color: colors.muted }]}>{subtitle}</Text>}
      </View>
      <IconSymbol name="chevron.right" size={16} color={colors.muted} />
    </Pressable>
  );
}

export default function ProfileScreen() {
  const colors = useColors();
  useInterstitialAd();  // Show interstitial ad when screen opens
  const { data: stats } = trpc.stats.overview.useQuery();

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>الإعدادات</Text>
        </View>

        {/* App Info */}
        <View style={[styles.appInfo, { backgroundColor: colors.surface }]}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.appLogo}
            contentFit="contain"
          />
          <View style={styles.appInfoText}>
            <Text style={[styles.appName, { color: colors.foreground }]}>أنمي سلاير</Text>
            <Text style={[styles.appVersion, { color: colors.muted }]}>الإصدار 1.0.0</Text>
            <Text style={[styles.appTagline, { color: colors.muted }]}>شاهد الأنمي مجاناً</Text>
          </View>
        </View>

        {/* Stats */}
        {stats && (
          <View style={styles.statsRow}>
            <View style={[styles.statItem, { backgroundColor: colors.surface }]}>
              <Text style={[styles.statValue, { color: colors.primary }]}>{stats.totalAnime}</Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>مسلسل</Text>
            </View>
            <View style={[styles.statItem, { backgroundColor: colors.surface }]}>
              <Text style={[styles.statValue, { color: colors.accent }]}>{stats.totalMovies}</Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>فيلم</Text>
            </View>
            <View style={[styles.statItem, { backgroundColor: colors.surface }]}>
              <Text style={[styles.statValue, { color: colors.success }]}>{stats.totalEpisodes}</Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>حلقة</Text>
            </View>
            <View style={[styles.statItem, { backgroundColor: colors.surface }]}>
              <Text style={[styles.statValue, { color: colors.warning }]}>{stats.totalViews.toLocaleString()}</Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>مشاهدة</Text>
            </View>
          </View>
        )}

        {/* Menu */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.muted }]}>التطبيق</Text>
          <View style={styles.menuGroup}>
            <MenuRow
              icon="heart.fill"
              label="المفضلة"
              subtitle="الأنمي المحفوظ"
              onPress={() => router.push("/(tabs)/favorites" as any)}
            />
            <MenuRow
              icon="clock.fill"
              label="سجل المشاهدة"
              subtitle="ما شاهدته مؤخراً"
              onPress={() => {}}
            />
            <MenuRow
              icon="square.and.arrow.up"
              label="مشاركة التطبيق"
              subtitle="شارك أنمي سلاير مع أصدقائك"
              onPress={() => {}}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.muted }]}>الإدارة</Text>
          <View style={styles.menuGroup}>
            <MenuRow
              icon="shield.fill"
              label="لوحة التحكم"
              subtitle="إدارة المحتوى والإحصائيات"
              onPress={() => router.push("/admin" as any)}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.muted }]}>حول</Text>
          <View style={styles.menuGroup}>
            <MenuRow
              icon="info.circle"
              label="عن التطبيق"
              subtitle="أنمي سلاير - شاهد الأنمي مجاناً"
              onPress={() => {}}
            />
          </View>
        </View>



        <View style={{ height: 30 }} />
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 0.5,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  appInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    margin: 16,
    padding: 16,
    borderRadius: 16,
  },
  appLogo: {
    width: 64,
    height: 64,
    borderRadius: 14,
  },
  appInfoText: {
    gap: 3,
  },
  appName: {
    fontSize: 18,
    fontWeight: "800",
  },
  appVersion: {
    fontSize: 12,
  },
  appTagline: {
    fontSize: 12,
  },
  statsRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    gap: 8,
    marginBottom: 8,
  },
  statItem: {
    flex: 1,
    borderRadius: 12,
    padding: 10,
    alignItems: "center",
    gap: 4,
  },
  statValue: {
    fontSize: 18,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 10,
    fontWeight: "600",
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 8,
    marginTop: 8,
  },
  menuGroup: {
    gap: 6,
  },
  menuRow: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    padding: 12,
    gap: 12,
  },
  menuIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  menuInfo: {
    flex: 1,
    gap: 2,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
  menuSubtitle: {
    fontSize: 11,
  },
});

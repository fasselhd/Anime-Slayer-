import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { addFavorite, isFavorite, removeFavorite } from "@/app/(tabs)/favorites";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

function EpisodeItem({ episode, animeId }: { episode: any; animeId: number }) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.episodeItem,
        { backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={() => router.push(`/player/${episode.id}` as any)}
    >
      <View style={[styles.episodeThumbnail, { backgroundColor: colors.surface2 }]}>
        {episode.thumbnailUrl ? (
          <Image source={{ uri: episode.thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <View style={[StyleSheet.absoluteFill, styles.noThumb]}>
            <IconSymbol name="play.circle.fill" size={28} color={colors.primary} />
          </View>
        )}
        <View style={[styles.playOverlay, { backgroundColor: "rgba(0,0,0,0.4)" }]}>
          <IconSymbol name="play.fill" size={16} color="#FFF" />
        </View>
      </View>
      <View style={styles.episodeInfo}>
        <Text style={[styles.episodeNumber, { color: colors.primary }]}>
          الحلقة {episode.number}
        </Text>
        <Text style={[styles.episodeTitle, { color: colors.foreground }]} numberOfLines={1}>
          {episode.titleAr || episode.title || `الحلقة ${episode.number}`}
        </Text>
        {episode.duration && (
          <Text style={[styles.episodeDuration, { color: colors.muted }]}>
            {Math.floor(episode.duration / 60)} دقيقة
          </Text>
        )}
      </View>
      <IconSymbol name="chevron.right" size={16} color={colors.muted} />
    </Pressable>
  );
}

export default function AnimeDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const animeId = parseInt(id ?? "0");
  const colors = useColors();

  const insets = useSafeAreaInsets();
  const [favorited, setFavorited] = useState(false);
  const [synopsisExpanded, setSynopsisExpanded] = useState(false);

  const { data: anime, isLoading } = trpc.anime.byId.useQuery({ id: animeId });
  const { data: episodes } = trpc.episodes.byAnimeId.useQuery({ animeId });
  const { data: genres } = trpc.genres.animeGenres.useQuery({ animeId });
  const incrementViews = trpc.anime.incrementViews.useMutation();

  useEffect(() => {
    if (animeId) {
      isFavorite(animeId).then(setFavorited);
      incrementViews.mutate({ id: animeId });
    }
  }, [animeId]);

  const toggleFavorite = async () => {
    if (!anime) return;
    if (favorited) {
      await removeFavorite(animeId);
      setFavorited(false);
    } else {
      await addFavorite({
        id: anime.id,
        title: anime.title,
        titleAr: anime.titleAr,
        coverUrl: anime.coverUrl,
        type: anime.type,
        status: anime.status,
        rating: anime.rating,
        year: anime.year,
      });
      setFavorited(true);
    }
  };

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!anime) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Text style={[styles.errorText, { color: colors.muted }]}>الأنمي غير موجود</Text>
        <Pressable onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: colors.primary }]}>
          <Text style={styles.backBtnText}>العودة</Text>
        </Pressable>
      </View>
    );
  }

  const statusLabel = anime.status === "ongoing" ? "يعرض" : anime.status === "completed" ? "مكتمل" : "قادم";
  const typeLabel = anime.type === "movie" ? "فيلم" : anime.type === "ova" ? "OVA" : anime.type === "special" ? "خاص" : "مسلسل";

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Banner */}
        <View style={styles.bannerContainer}>
          <Image
            source={{ uri: anime.bannerUrl || anime.coverUrl || "" }}
            style={styles.banner}
            contentFit="cover"
          />
          <LinearGradient
            colors={["rgba(13,13,13,0.3)", "rgba(13,13,13,0.8)", "#0D0D0D"]}
            style={StyleSheet.absoluteFill}
          />
          {/* Back Button */}
          <Pressable
            style={[styles.backButton, { top: insets.top + 10, backgroundColor: "rgba(0,0,0,0.5)" }]}
            onPress={() => router.back()}
          >
            <IconSymbol name="arrow.left" size={20} color="#FFF" />
          </Pressable>
          {/* Favorite Button */}
          <Pressable
            style={[styles.favoriteButton, { top: insets.top + 10, backgroundColor: "rgba(0,0,0,0.5)" }]}
            onPress={toggleFavorite}
          >
            <IconSymbol name={favorited ? "heart.fill" : "heart"} size={20} color={favorited ? colors.accent : "#FFF"} />
          </Pressable>
        </View>

        {/* Info Section */}
        <View style={styles.infoSection}>
          {/* Cover + Basic Info */}
          <View style={styles.coverRow}>
            <View style={styles.coverWrapper}>
              <Image
                source={{ uri: anime.coverUrl || "" }}
                style={styles.cover}
                contentFit="cover"
              />
            </View>
            <View style={styles.basicInfo}>
              <Text style={[styles.title, { color: colors.foreground }]}>{anime.titleAr || anime.title}</Text>
              {anime.titleAr && anime.title !== anime.titleAr && (
                <Text style={[styles.titleEn, { color: colors.muted }]}>{anime.title}</Text>
              )}
              <View style={styles.badges}>
                <View style={[styles.badge, { backgroundColor: anime.type === "movie" ? colors.accent : colors.primary }]}>
                  <Text style={styles.badgeText}>{typeLabel}</Text>
                </View>
                <View style={[styles.badge, { backgroundColor: colors.surface }]}>
                  <Text style={[styles.badgeText, { color: colors.muted }]}>{statusLabel}</Text>
                </View>
              </View>
              {anime.rating && parseFloat(anime.rating) > 0 && (
                <Text style={[styles.rating, { color: "#F59E0B" }]}>
                  ⭐ {parseFloat(anime.rating).toFixed(1)} / 10
                </Text>
              )}
              <View style={styles.metaRow}>
                {anime.year && (
                  <Text style={[styles.metaItem, { color: colors.muted }]}>📅 {anime.year}</Text>
                )}
                {anime.studio && (
                  <Text style={[styles.metaItem, { color: colors.muted }]}>🎬 {anime.studio}</Text>
                )}
                {anime.totalEpisodes && (
                  <Text style={[styles.metaItem, { color: colors.muted }]}>📺 {anime.totalEpisodes} حلقة</Text>
                )}
              </View>
            </View>
          </View>

          {/* Genres */}
          {genres && genres.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.genresRow}>
              {genres.map(({ genre }) => (
                <View
                  key={genre.id}
                  style={[styles.genreChip, { backgroundColor: genre.color + "33", borderColor: genre.color || colors.border }]}
                >
                  <Text style={[styles.genreText, { color: genre.color || colors.primary }]}>
                    {genre.nameAr || genre.name}
                  </Text>
                </View>
              ))}
            </ScrollView>
          )}

          {/* Synopsis */}
          {anime.synopsis && (
            <View style={styles.synopsisSection}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>القصة</Text>
              <Text
                style={[styles.synopsis, { color: colors.muted }]}
                numberOfLines={synopsisExpanded ? undefined : 3}
              >
                {anime.synopsis}
              </Text>
              <Pressable onPress={() => setSynopsisExpanded(!synopsisExpanded)}>
                <Text style={[styles.expandBtn, { color: colors.primary }]}>
                  {synopsisExpanded ? "عرض أقل" : "عرض المزيد"}
                </Text>
              </Pressable>
            </View>
          )}

          {/* Watch Button (for movies) */}
          {anime.type === "movie" && episodes && episodes.length > 0 && (
            <Pressable
              style={[styles.watchBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push(`/player/${episodes[0].id}` as any)}
            >
              <IconSymbol name="play.fill" size={18} color="#FFF" />
              <Text style={styles.watchBtnText}>شاهد الفيلم</Text>
            </Pressable>
          )}

          {/* Episodes */}
          {anime.type !== "movie" && (
            <View style={styles.episodesSection}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                الحلقات ({episodes?.length ?? 0})
              </Text>
              {episodes && episodes.length > 0 ? (
                episodes.map((ep) => (
                  <EpisodeItem key={ep.id} episode={ep} animeId={animeId} />
                ))
              ) : (
                <View style={[styles.noEpisodes, { backgroundColor: colors.surface }]}>
                  <Text style={[styles.noEpisodesText, { color: colors.muted }]}>
                    لا توجد حلقات بعد
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* Stats */}
          <View style={[styles.statsRow, { borderTopColor: colors.border }]}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.foreground }]}>
                {anime.views.toLocaleString()}
              </Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>مشاهدة</Text>
            </View>
            {episodes && (
              <View style={styles.statItem}>
                <Text style={[styles.statValue, { color: colors.foreground }]}>{episodes.length}</Text>
                <Text style={[styles.statLabel, { color: colors.muted }]}>حلقة</Text>
              </View>
            )}
          </View>

          <View style={{ height: 30 }} />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
  },
  errorText: {
    fontSize: 16,
  },
  backBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginTop: 12,
  },
  backBtnText: {
    color: "#FFF",
    fontWeight: "700",
  },
  bannerContainer: {
    height: 250,
  },
  banner: {
    width: "100%",
    height: "100%",
  },
  backButton: {
    position: "absolute",
    left: 16,
    width: 38,
    height: 38,
    borderRadius: 19,
    justifyContent: "center",
    alignItems: "center",
  },
  favoriteButton: {
    position: "absolute",
    right: 16,
    width: 38,
    height: 38,
    borderRadius: 19,
    justifyContent: "center",
    alignItems: "center",
  },
  infoSection: {
    padding: 16,
    marginTop: -20,
  },
  coverRow: {
    flexDirection: "row",
    gap: 14,
    marginBottom: 16,
  },
  coverWrapper: {
    width: 100,
    height: 145,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#1A1A2E",
    marginTop: -30,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  cover: {
    width: "100%",
    height: "100%",
  },
  basicInfo: {
    flex: 1,
    gap: 6,
  },
  title: {
    fontSize: 18,
    fontWeight: "800",
    lineHeight: 24,
  },
  titleEn: {
    fontSize: 12,
    lineHeight: 16,
  },
  badges: {
    flexDirection: "row",
    gap: 6,
    flexWrap: "wrap",
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  badgeText: {
    color: "#FFF",
    fontSize: 11,
    fontWeight: "700",
  },
  rating: {
    fontSize: 14,
    fontWeight: "600",
  },
  metaRow: {
    gap: 4,
  },
  metaItem: {
    fontSize: 11,
    lineHeight: 16,
  },
  genresRow: {
    marginBottom: 16,
  },
  genreChip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    marginRight: 8,
  },
  genreText: {
    fontSize: 12,
    fontWeight: "600",
  },
  synopsisSection: {
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 8,
  },
  synopsis: {
    fontSize: 13,
    lineHeight: 20,
  },
  expandBtn: {
    fontSize: 12,
    fontWeight: "600",
    marginTop: 4,
  },
  watchBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    marginBottom: 20,
  },
  watchBtnText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "700",
  },
  episodesSection: {
    marginBottom: 16,
  },
  episodeItem: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    marginBottom: 8,
    overflow: "hidden",
  },
  episodeThumbnail: {
    width: 100,
    height: 65,
  },
  noThumb: {
    justifyContent: "center",
    alignItems: "center",
  },
  playOverlay: {
    position: "absolute",
    bottom: 6,
    right: 6,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  episodeInfo: {
    flex: 1,
    padding: 10,
    gap: 3,
  },
  episodeNumber: {
    fontSize: 11,
    fontWeight: "700",
  },
  episodeTitle: {
    fontSize: 13,
    fontWeight: "600",
  },
  episodeDuration: {
    fontSize: 10,
  },
  noEpisodes: {
    padding: 20,
    borderRadius: 12,
    alignItems: "center",
  },
  noEpisodesText: {
    fontSize: 13,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingTop: 16,
    borderTopWidth: 0.5,
    marginTop: 8,
  },
  statItem: {
    alignItems: "center",
    gap: 4,
  },
  statValue: {
    fontSize: 18,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 11,
  },
});

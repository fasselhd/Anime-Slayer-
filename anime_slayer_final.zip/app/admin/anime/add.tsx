import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { checkAdminAuth } from "../login";

function FormField({
  label,
  value,
  onChangeText,
  placeholder,
  multiline,
  keyboardType,
  required,
}: {
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  placeholder?: string;
  multiline?: boolean;
  keyboardType?: "default" | "numeric" | "url";
  required?: boolean;
}) {
  const colors = useColors();
  return (
    <View style={styles.fieldContainer}>
      <Text style={[styles.fieldLabel, { color: colors.muted }]}>
        {label} {required && <Text style={{ color: colors.error }}>*</Text>}
      </Text>
      <TextInput
        style={[
          styles.fieldInput,
          {
            backgroundColor: colors.surface,
            borderColor: colors.border,
            color: colors.foreground,
            height: multiline ? 80 : 44,
            textAlignVertical: multiline ? "top" : "center",
          },
        ]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        multiline={multiline}
        keyboardType={keyboardType}
        textAlign="right"
      />
    </View>
  );
}

function SelectField({
  label,
  value,
  options,
  onSelect,
}: {
  label: string;
  value: string;
  options: { label: string; value: string }[];
  onSelect: (v: string) => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.fieldContainer}>
      <Text style={[styles.fieldLabel, { color: colors.muted }]}>{label}</Text>
      <View style={styles.selectRow}>
        {options.map((opt) => (
          <Pressable
            key={opt.value}
            style={[
              styles.selectOption,
              {
                backgroundColor: value === opt.value ? colors.primary : colors.surface,
                borderColor: value === opt.value ? colors.primary : colors.border,
              },
            ]}
            onPress={() => onSelect(opt.value)}
          >
            <Text style={[styles.selectOptionText, { color: value === opt.value ? "#FFF" : colors.muted }]}>
              {opt.label}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export default function AddAnimeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [title, setTitle] = useState("");
  const [titleAr, setTitleAr] = useState("");
  const [synopsis, setSynopsis] = useState("");
  const [coverUrl, setCoverUrl] = useState("");
  const [bannerUrl, setBannerUrl] = useState("");
  const [trailerUrl, setTrailerUrl] = useState("");
  const [type, setType] = useState("series");
  const [status, setStatus] = useState("ongoing");
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [rating, setRating] = useState("");
  const [studio, setStudio] = useState("");
  const [totalEpisodes, setTotalEpisodes] = useState("");
  const [isFeatured, setIsFeatured] = useState(false);
  const [isTrending, setIsTrending] = useState(false);
  const [loading, setLoading] = useState(false);

  useFocusEffect(
    useCallback(() => {
      checkAdminAuth().then((auth) => {
        if (!auth) router.replace("/admin/login" as any);
      });
    }, [])
  );

  const createAnime = trpc.anime.create.useMutation({
    onSuccess: (data) => {
      Alert.alert("نجح", "تم إضافة الأنمي بنجاح!", [
        {
          text: "إضافة حلقات",
          onPress: () => router.replace(`/admin/episodes/${data.id}` as any),
        },
        {
          text: "إضافة أنمي آخر",
          onPress: () => {
            setTitle(""); setTitleAr(""); setSynopsis(""); setCoverUrl("");
            setBannerUrl(""); setTrailerUrl(""); setRating(""); setStudio("");
            setTotalEpisodes(""); setIsFeatured(false); setIsTrending(false);
          },
        },
        { text: "العودة", onPress: () => router.back() },
      ]);
    },
    onError: (err) => {
      Alert.alert("خطأ", err.message || "فشل في إضافة الأنمي");
    },
  });

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert("خطأ", "اسم الأنمي مطلوب");
      return;
    }
    setLoading(true);
    try {
      await createAnime.mutateAsync({
        title: title.trim(),
        titleAr: titleAr.trim() || undefined,
        synopsis: synopsis.trim() || undefined,
        coverUrl: coverUrl.trim() || undefined,
        bannerUrl: bannerUrl.trim() || undefined,
        trailerUrl: trailerUrl.trim() || undefined,
        type: type as any,
        status: status as any,
        year: year ? parseInt(year) : undefined,
        rating: rating || undefined,
        studio: studio.trim() || undefined,
        totalEpisodes: totalEpisodes ? parseInt(totalEpisodes) : undefined,
        isFeatured,
        isTrending,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="arrow.left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>إضافة أنمي جديد</Text>
        <Pressable
          style={[styles.saveBtn, { backgroundColor: loading ? colors.muted : colors.primary }]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <Text style={styles.saveBtnText}>{loading ? "..." : "حفظ"}</Text>
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.form} showsVerticalScrollIndicator={false}>
        <FormField label="اسم الأنمي (إنجليزي)" value={title} onChangeText={setTitle} placeholder="Attack on Titan" required />
        <FormField label="اسم الأنمي (عربي)" value={titleAr} onChangeText={setTitleAr} placeholder="هجوم العمالقة" />
        <FormField label="القصة" value={synopsis} onChangeText={setSynopsis} placeholder="قصة الأنمي..." multiline />
        <FormField label="رابط الصورة الرئيسية" value={coverUrl} onChangeText={setCoverUrl} placeholder="https://..." keyboardType="url" />
        <FormField label="رابط صورة البانر" value={bannerUrl} onChangeText={setBannerUrl} placeholder="https://..." keyboardType="url" />
        <FormField label="رابط المقطع الدعائي" value={trailerUrl} onChangeText={setTrailerUrl} placeholder="https://..." keyboardType="url" />
        <FormField label="الاستوديو" value={studio} onChangeText={setStudio} placeholder="MAPPA, Ufotable..." />
        <FormField label="سنة الإصدار" value={year} onChangeText={setYear} placeholder="2024" keyboardType="numeric" />
        <FormField label="التقييم (0-10)" value={rating} onChangeText={setRating} placeholder="8.5" keyboardType="numeric" />
        <FormField label="عدد الحلقات" value={totalEpisodes} onChangeText={setTotalEpisodes} placeholder="24" keyboardType="numeric" />

        <SelectField
          label="النوع"
          value={type}
          options={[
            { label: "مسلسل", value: "series" },
            { label: "فيلم", value: "movie" },
            { label: "OVA", value: "ova" },
            { label: "خاص", value: "special" },
          ]}
          onSelect={setType}
        />

        <SelectField
          label="الحالة"
          value={status}
          options={[
            { label: "يعرض", value: "ongoing" },
            { label: "مكتمل", value: "completed" },
            { label: "قادم", value: "upcoming" },
          ]}
          onSelect={setStatus}
        />

        {/* Toggles */}
        <View style={[styles.toggleRow, { borderTopColor: colors.border }]}>
          <View style={styles.toggleItem}>
            <View>
              <Text style={[styles.toggleLabel, { color: colors.foreground }]}>مميز (Featured)</Text>
              <Text style={[styles.toggleHint, { color: colors.muted }]}>يظهر في البانر الرئيسي</Text>
            </View>
            <Switch
              value={isFeatured}
              onValueChange={setIsFeatured}
              trackColor={{ true: colors.primary }}
            />
          </View>
          <View style={styles.toggleItem}>
            <View>
              <Text style={[styles.toggleLabel, { color: colors.foreground }]}>رائج (Trending)</Text>
              <Text style={[styles.toggleHint, { color: colors.muted }]}>يظهر في قسم الأكثر مشاهدة</Text>
            </View>
            <Switch
              value={isTrending}
              onValueChange={setIsTrending}
              trackColor={{ true: colors.primary }}
            />
          </View>
        </View>

        <Pressable
          style={[styles.submitBtn, { backgroundColor: loading ? colors.muted : colors.primary }]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <IconSymbol name="plus" size={18} color="#FFF" />
          <Text style={styles.submitBtnText}>{loading ? "جاري الحفظ..." : "إضافة الأنمي"}</Text>
        </Pressable>

        <View style={{ height: 40 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 0.5,
  },
  backBtn: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "800",
  },
  saveBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 10,
  },
  saveBtnText: {
    color: "#FFF",
    fontWeight: "700",
    fontSize: 14,
  },
  form: {
    padding: 16,
    gap: 4,
  },
  fieldContainer: {
    marginBottom: 12,
  },
  fieldLabel: {
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 6,
  },
  fieldInput: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  selectRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  selectOption: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  selectOptionText: {
    fontSize: 13,
    fontWeight: "600",
  },
  toggleRow: {
    borderTopWidth: 0.5,
    paddingTop: 16,
    marginTop: 4,
    gap: 12,
    marginBottom: 16,
  },
  toggleItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  toggleLabel: {
    fontSize: 14,
    fontWeight: "600",
  },
  toggleHint: {
    fontSize: 11,
    marginTop: 2,
  },
  submitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
  submitBtnText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "700",
  },
});

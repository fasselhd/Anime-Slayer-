import { Image } from "expo-image";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import {
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { checkAdminAuth } from "../login";

export default function AdminAnimeListScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const { data: animeList, refetch, isLoading } = trpc.anime.list.useQuery({
    limit: 100,
    offset: 0,
    search: search.length >= 2 ? search : undefined,
  });

  const deleteAnime = trpc.anime.delete.useMutation({
    onSuccess: () => refetch(),
  });

  useFocusEffect(
    useCallback(() => {
      checkAdminAuth().then((auth) => {
        if (!auth) router.replace("/admin/login" as any);
      });
    }, [])
  );

  const handleDelete = (id: number, title: string) => {
    Alert.alert(
      "حذف الأنمي",
      `هل تريد حذف "${title}"؟ سيتم حذف جميع الحلقات أيضاً.`,
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "حذف",
          style: "destructive",
          onPress: () => deleteAnime.mutate({ id }),
        },
      ]
    );
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="arrow.left" size={20} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>إدارة الأنمي</Text>
        <Pressable
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => router.push("/admin/anime/add" as any)}
        >
          <IconSymbol name="plus" size={18} color="#FFF" />
        </Pressable>
      </View>

      {/* Search */}
      <View style={[styles.searchContainer, { borderBottomColor: colors.border }]}>
        <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="magnifyingglass" size={16} color={colors.muted} />
          <TextInput
            style={[styles.searchInput, { color: colors.foreground }]}
            placeholder="بحث عن أنمي..."
            placeholderTextColor={colors.muted}
            value={search}
            onChangeText={setSearch}
            textAlign="right"
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")}>
              <IconSymbol name="xmark" size={14} color={colors.muted} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Count */}
      <View style={styles.countRow}>
        <Text style={[styles.countText, { color: colors.muted }]}>
          {isLoading ? "جاري التحميل..." : `${animeList?.length ?? 0} عنصر`}
        </Text>
      </View>

      {/* List */}
      <FlatList
        data={animeList}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />
        }
        renderItem={({ item }) => (
          <View style={[styles.animeItem, { backgroundColor: colors.surface }]}>
            <View style={styles.animeCover}>
              {item.coverUrl ? (
                <Image source={{ uri: item.coverUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
              ) : (
                <View style={[StyleSheet.absoluteFill, styles.noCover, { backgroundColor: colors.surface2 }]}>
                  <Text style={{ fontSize: 20 }}>🎌</Text>
                </View>
              )}
            </View>
            <View style={styles.animeInfo}>
              <Text style={[styles.animeTitle, { color: colors.foreground }]} numberOfLines={2}>
                {item.titleAr || item.title}
              </Text>
              <View style={styles.animeMeta}>
                <View style={[styles.typeBadge, { backgroundColor: item.type === "movie" ? colors.accent : colors.primary }]}>
                  <Text style={styles.typeBadgeText}>{item.type === "movie" ? "فيلم" : "مسلسل"}</Text>
                </View>
                <Text style={[styles.metaText, { color: colors.muted }]}>{item.year ?? "—"}</Text>
                <Text style={[styles.metaText, { color: colors.muted }]}>👁️ {item.views}</Text>
              </View>
            </View>
            <View style={styles.actions}>
              <Pressable
                style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.primary + "22", opacity: pressed ? 0.7 : 1 }]}
                onPress={() => router.push(`/admin/anime/${item.id}/edit` as any)}
              >
                <IconSymbol name="pencil" size={16} color={colors.primary} />
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.error + "22", opacity: pressed ? 0.7 : 1 }]}
                onPress={() => handleDelete(item.id, item.titleAr || item.title)}
              >
                <IconSymbol name="trash" size={16} color={colors.error} />
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.success + "22", opacity: pressed ? 0.7 : 1 }]}
                onPress={() => router.push(`/admin/episodes/${item.id}` as any)}
              >
                <IconSymbol name="list.bullet" size={16} color={colors.success} />
              </Pressable>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📭</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {isLoading ? "جاري التحميل..." : "لا توجد أنمي"}
            </Text>
            <Pressable
              style={[styles.addFirstBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push("/admin/anime/add" as any)}
            >
              <Text style={styles.addFirstBtnText}>إضافة أول أنمي</Text>
            </Pressable>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 0.5,
  },
  backBtn: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "800",
  },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
  },
  searchContainer: {
    padding: 12,
    borderBottomWidth: 0.5,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
  },
  countRow: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  countText: {
    fontSize: 12,
  },
  list: {
    padding: 12,
    gap: 8,
  },
  animeItem: {
    flexDirection: "row",
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 8,
    alignItems: "center",
  },
  animeCover: {
    width: 65,
    height: 90,
    backgroundColor: "#1A1A2E",
  },
  noCover: {
    justifyContent: "center",
    alignItems: "center",
  },
  animeInfo: {
    flex: 1,
    padding: 10,
    gap: 6,
  },
  animeTitle: {
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 18,
  },
  animeMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  typeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  typeBadgeText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "700",
  },
  metaText: {
    fontSize: 10,
  },
  actions: {
    flexDirection: "row",
    gap: 6,
    padding: 10,
  },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyState: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  emptyEmoji: {
    fontSize: 48,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  addFirstBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  addFirstBtnText: {
    color: "#FFF",
    fontWeight: "700",
  },
});

import { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { trpc } from "@/lib/trpc";
import { ScreenContainer } from "@/components/screen-container";
import { checkAdminAuth } from "./login";

export default function AdminSettingsScreen() {
  const router = useRouter();
  const [isAuthed, setIsAuthed] = useState(false);
  const [loading, setLoading] = useState(true);

  // Ad Unit IDs
  const [interstitialAdId, setInterstitialAdId] = useState("");
  const [rewardedAdId, setRewardedAdId] = useState("");
  const [bannerAdId, setBannerAdId] = useState("");
  const [saving, setSaving] = useState(false);

  // Fetch current settings
  const getInterstitialAd = trpc.settings.get.useQuery(
    { key: "interstitial_ad_unit_id" },
    { enabled: isAuthed }
  );
  const getRewardedAd = trpc.settings.get.useQuery(
    { key: "rewarded_ad_unit_id" },
    { enabled: isAuthed }
  );
  const getBannerAd = trpc.settings.get.useQuery(
    { key: "banner_ad_unit_id" },
    { enabled: isAuthed }
  );

  // Save settings mutations
  const saveInterstitial = trpc.settings.set.useMutation();
  const saveRewarded = trpc.settings.set.useMutation();
  const saveBanner = trpc.settings.set.useMutation();

  // Check auth on mount
  useEffect(() => {
    const checkAuth = async () => {
      const authed = await checkAdminAuth();
      if (!authed) {
        router.replace("/admin/login");
        return;
      }
      setIsAuthed(true);
      setLoading(false);
    };
    checkAuth();
  }, []);

  // Load settings
  useEffect(() => {
    if (getInterstitialAd.data) {
      setInterstitialAdId(getInterstitialAd.data || "ca-app-pub-7032269320751343/1591409450");
    }
    if (getRewardedAd.data) {
      setRewardedAdId(getRewardedAd.data || "");
    }
    if (getBannerAd.data) {
      setBannerAdId(getBannerAd.data || "");
    }
  }, [getInterstitialAd.data, getRewardedAd.data, getBannerAd.data]);

  const handleSaveAll = async () => {
    if (!interstitialAdId.trim()) {
      Alert.alert("خطأ", "رمز الإعلان البيني مطلوب");
      return;
    }

    setSaving(true);
    try {
      await Promise.all([
        saveInterstitial.mutateAsync({
          key: "interstitial_ad_unit_id",
          value: interstitialAdId.trim(),
        }),
        rewardedAdId.trim() &&
          saveRewarded.mutateAsync({
            key: "rewarded_ad_unit_id",
            value: rewardedAdId.trim(),
          }),
        bannerAdId.trim() &&
          saveBanner.mutateAsync({
            key: "banner_ad_unit_id",
            value: bannerAdId.trim(),
          }),
      ]);
      Alert.alert("نجح", "تم حفظ إعدادات الإعلانات بنجاح");
    } catch (error) {
      Alert.alert("خطأ", "فشل حفظ الإعدادات");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="justify-center items-center">
        <ActivityIndicator size="large" color="#E53935" />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {/* Header */}
        <View className="flex-row items-center justify-between px-4 py-4 border-b border-border">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-2xl">←</Text>
          </TouchableOpacity>
          <Text className="text-xl font-bold text-foreground">إعدادات الإعلانات</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* Settings Form */}
        <View className="px-4 py-6 gap-6">
          {/* Interstitial Ad Unit ID */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">
              رمز الإعلان البيني (Interstitial)
            </Text>
            <Text className="text-xs text-muted mb-3">
              يظهر هذا الإعلان عند فتح الحلقات والمشغل
            </Text>
            <TextInput
              value={interstitialAdId}
              onChangeText={setInterstitialAdId}
              placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx"
              placeholderTextColor="#999"
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              editable={!saving}
            />
          </View>

          {/* Rewarded Ad Unit ID */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">
              رمز الإعلان المكافأة (Rewarded) - اختياري
            </Text>
            <Text className="text-xs text-muted mb-3">
              يظهر قبل مشاهدة الحلقة للحصول على مكافأة
            </Text>
            <TextInput
              value={rewardedAdId}
              onChangeText={setRewardedAdId}
              placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx"
              placeholderTextColor="#999"
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              editable={!saving}
            />
          </View>

          {/* Banner Ad Unit ID */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">
              رمز إعلان البانر (Banner) - اختياري
            </Text>
            <Text className="text-xs text-muted mb-3">
              يظهر في أسفل الشاشات
            </Text>
            <TextInput
              value={bannerAdId}
              onChangeText={setBannerAdId}
              placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx"
              placeholderTextColor="#999"
              className="bg-surface border border-border rounded-lg px-4 py-3 text-foreground"
              editable={!saving}
            />
          </View>

          {/* Info Box */}
          <View className="bg-primary/10 border border-primary rounded-lg p-4">
            <Text className="text-sm text-foreground font-semibold mb-2">📝 ملاحظة مهمة</Text>
            <Text className="text-xs text-muted leading-5">
              تأكد من أن رموز الإعلانات صحيحة وفعالة في حسابك على Google AdMob. التطبيق سيستخدم هذه الرموز تلقائياً عند إعادة تشغيله.
            </Text>
          </View>

          {/* Save Button */}
          <TouchableOpacity
            onPress={handleSaveAll}
            disabled={saving}
            className="bg-primary rounded-lg py-4 items-center"
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-bold text-base">حفظ الإعدادات</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";

const ADMIN_PASSWORD = "AbcA_2250";
const ADMIN_AUTH_KEY = "admin_authenticated";

export async function checkAdminAuth(): Promise<boolean> {
  try {
    const val = await AsyncStorage.getItem(ADMIN_AUTH_KEY);
    return val === "true";
  } catch {
    return false;
  }
}

export async function setAdminAuth(value: boolean): Promise<void> {
  await AsyncStorage.setItem(ADMIN_AUTH_KEY, value ? "true" : "false");
}

export default function AdminLoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!password) {
      Alert.alert("خطأ", "أدخل كلمة المرور");
      return;
    }
    setLoading(true);
    // Simulate a small delay
    await new Promise((r) => setTimeout(r, 500));
    if (password === ADMIN_PASSWORD) {
      await setAdminAuth(true);
      router.replace("/admin" as any);
    } else {
      Alert.alert("خطأ", "كلمة المرور غير صحيحة");
    }
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={[styles.content, { paddingTop: insets.top + 40 }]}>
        {/* Back Button */}
        <Pressable
          style={[styles.backBtn, { top: insets.top + 10 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="arrow.left" size={20} color={colors.foreground} />
        </Pressable>

        {/* Logo */}
        <View style={styles.logoContainer}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.logo}
            contentFit="contain"
          />
          <Text style={[styles.appName, { color: colors.foreground }]}>أنمي سلاير</Text>
          <View style={[styles.adminBadge, { backgroundColor: colors.accent }]}>
            <Text style={styles.adminBadgeText}>لوحة التحكم</Text>
          </View>
        </View>

        {/* Login Form */}
        <View style={[styles.form, { backgroundColor: colors.surface }]}>
          <Text style={[styles.formTitle, { color: colors.foreground }]}>تسجيل دخول المشرف</Text>
          <Text style={[styles.formSubtitle, { color: colors.muted }]}>
            أدخل كلمة مرور لوحة التحكم للمتابعة
          </Text>

          <View style={[styles.inputWrapper, { borderColor: colors.border, backgroundColor: colors.background }]}>
            <IconSymbol name="lock.fill" size={18} color={colors.muted} />
            <TextInput
              style={[styles.input, { color: colors.foreground }]}
              placeholder="كلمة المرور"
              placeholderTextColor={colors.muted}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={true}
              returnKeyType="done"
              onSubmitEditing={handleLogin}
              textAlign="right"
            />
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.loginBtn,
              { backgroundColor: loading ? colors.muted : colors.primary, opacity: pressed ? 0.9 : 1 },
            ]}
            onPress={handleLogin}
            disabled={loading}
          >
            <Text style={styles.loginBtnText}>{loading ? "جاري التحقق..." : "دخول"}</Text>
          </Pressable>


        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 24,
    alignItems: "center",
  },
  backBtn: {
    position: "absolute",
    left: 20,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  logoContainer: {
    alignItems: "center",
    gap: 8,
    marginBottom: 40,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 20,
  },
  appName: {
    fontSize: 24,
    fontWeight: "800",
  },
  adminBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  adminBadgeText: {
    color: "#FFF",
    fontSize: 12,
    fontWeight: "700",
  },
  form: {
    width: "100%",
    borderRadius: 20,
    padding: 24,
    gap: 16,
  },
  formTitle: {
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
  },
  formSubtitle: {
    fontSize: 13,
    textAlign: "center",
    lineHeight: 18,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 10,
  },
  input: {
    flex: 1,
    fontSize: 15,
  },
  loginBtn: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 4,
  },
  loginBtnText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "700",
  },
  hint: {
    fontSize: 11,
    textAlign: "center",
  },
});

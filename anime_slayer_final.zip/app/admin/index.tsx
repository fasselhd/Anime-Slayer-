import AsyncStorage from "@react-native-async-storage/async-storage";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { checkAdminAuth, setAdminAuth } from "./login";

function StatCard({ icon, value, label, color }: { icon: string; value: string | number; label: string; color: string }) {
  const colors = useColors();
  return (
    <View style={[styles.statCard, { backgroundColor: colors.surface }]}>
      <View style={[styles.statIcon, { backgroundColor: color + "22" }]}>
        <Text style={styles.statEmoji}>{icon}</Text>
      </View>
      <Text style={[styles.statValue, { color: colors.foreground }]}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </Text>
      <Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

function QuickActionBtn({ icon, label, color, onPress }: { icon: any; label: string; color: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.quickAction,
        { backgroundColor: colors.surface, opacity: pressed ? 0.8 : 1 },
      ]}
      onPress={onPress}
    >
      <View style={[styles.quickActionIcon, { backgroundColor: color }]}>
        <IconSymbol name={icon} size={22} color="#FFF" />
      </View>
      <Text style={[styles.quickActionLabel, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export default function AdminDashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const { data: stats, refetch: refetchStats } = trpc.stats.overview.useQuery();
  const { data: recentAnime, refetch: refetchRecent } = trpc.anime.recent.useQuery({ limit: 5 });
  const seedGenres = trpc.genres.seed.useMutation();

  useFocusEffect(
    useCallback(() => {
      checkAdminAuth().then((auth) => {
        setAuthenticated(auth);
        if (!auth) {
          router.replace("/admin/login" as any);
        }
      });
    }, [])
  );

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchStats(), refetchRecent()]);
    setRefreshing(false);
  };

  const handleLogout = () => {
    Alert.alert("تسجيل الخروج", "هل تريد الخروج من لوحة التحكم؟", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "خروج",
        style: "destructive",
        onPress: async () => {
          await setAdminAuth(false);
          router.replace("/" as any);
        },
      },
    ]);
  };

  const handleSeedGenres = async () => {
    try {
      await seedGenres.mutateAsync();
      Alert.alert("نجح", "تم إضافة التصنيفات الافتراضية");
    } catch {
      Alert.alert("خطأ", "فشل في إضافة التصنيفات");
    }
  };

  if (authenticated === null) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!authenticated) return null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.headerBackBtn}>
          <IconSymbol name="arrow.left" size={20} color={colors.foreground} />
        </Pressable>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>لوحة التحكم</Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>أنمي سلاير</Text>
        </View>
        <Pressable onPress={handleLogout} style={styles.logoutBtn}>
          <IconSymbol name="arrow.right" size={20} color={colors.error} />
        </Pressable>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />
        }
      >
        {/* Stats Grid */}
        <View style={styles.statsSection}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>الإحصائيات</Text>
          <View style={styles.statsGrid}>
            <StatCard icon="📺" value={stats?.totalAnime ?? 0} label="مسلسلات" color="#1A6DFF" />
            <StatCard icon="🎬" value={stats?.totalMovies ?? 0} label="أفلام" color="#E94560" />
            <StatCard icon="🎞️" value={stats?.totalEpisodes ?? 0} label="حلقات" color="#22C55E" />
            <StatCard icon="👁️" value={stats?.totalViews ?? 0} label="مشاهدة" color="#F59E0B" />
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.actionsSection}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>إجراءات سريعة</Text>
          <View style={styles.actionsGrid}>
            <QuickActionBtn
              icon="plus"
              label="إضافة أنمي"
              color="#1A6DFF"
              onPress={() => router.push("/admin/anime/add" as any)}
            />
            <QuickActionBtn
              icon="list.bullet"
              label="إدارة الأنمي"
              color="#8B5CF6"
              onPress={() => router.push("/admin/anime" as any)}
            />
            <QuickActionBtn
              icon="sparkles"
              label="إضافة تصنيفات"
              color="#22C55E"
              onPress={handleSeedGenres}
            />
            <QuickActionBtn
              icon="gear"
              label="إعدادات الإعلانات"
              color="#E94560"
              onPress={() => router.push("/admin/settings" as any)}
            />
            <QuickActionBtn
              icon="chart.bar.fill"
              label="الإحصائيات"
              color="#F59E0B"
              onPress={() => {}}
            />
          </View>
        </View>

        {/* Recent Additions */}
        <View style={styles.recentSection}>
          <View style={styles.recentHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>آخر الإضافات</Text>
            <Pressable onPress={() => router.push("/admin/anime" as any)}>
              <Text style={[styles.viewAll, { color: colors.primary }]}>عرض الكل</Text>
            </Pressable>
          </View>
          {recentAnime?.map((item) => (
            <Pressable
              key={item.id}
              style={[styles.recentItem, { backgroundColor: colors.surface }]}
              onPress={() => router.push(`/admin/anime/${item.id}/edit` as any)}
            >
              <View style={[styles.recentIcon, { backgroundColor: item.type === "movie" ? colors.accent + "22" : colors.primary + "22" }]}>
                <Text style={{ fontSize: 18 }}>{item.type === "movie" ? "🎬" : "📺"}</Text>
              </View>
              <View style={styles.recentInfo}>
                <Text style={[styles.recentTitle, { color: colors.foreground }]} numberOfLines={1}>
                  {item.titleAr || item.title}
                </Text>
                <Text style={[styles.recentMeta, { color: colors.muted }]}>
                  {item.type === "movie" ? "فيلم" : "مسلسل"} • {item.year ?? "غير محدد"}
                </Text>
              </View>
              <View style={[styles.recentViews, { backgroundColor: colors.background }]}>
                <Text style={[styles.recentViewsText, { color: colors.muted }]}>
                  {item.views.toLocaleString()} 👁️
                </Text>
              </View>
            </Pressable>
          ))}
          {(!recentAnime || recentAnime.length === 0) && (
            <View style={[styles.emptyRecent, { backgroundColor: colors.surface }]}>
              <Text style={[styles.emptyRecentText, { color: colors.muted }]}>
                لا توجد إضافات بعد. ابدأ بإضافة أنمي!
              </Text>
            </View>
          )}
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 0.5,
  },
  headerBackBtn: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "800",
    textAlign: "center",
  },
  headerSubtitle: {
    fontSize: 11,
    textAlign: "center",
  },
  logoutBtn: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  statsSection: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 12,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  statCard: {
    width: "47%",
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
    gap: 6,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  statEmoji: {
    fontSize: 22,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 12,
    fontWeight: "600",
  },
  actionsSection: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  quickAction: {
    width: "47%",
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
    gap: 8,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  quickActionLabel: {
    fontSize: 13,
    fontWeight: "600",
  },
  recentSection: {
    paddingHorizontal: 16,
  },
  recentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  viewAll: {
    fontSize: 13,
    fontWeight: "600",
  },
  recentItem: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  recentIcon: {
    width: 44,
    height: 44,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  recentInfo: {
    flex: 1,
    gap: 3,
  },
  recentTitle: {
    fontSize: 13,
    fontWeight: "600",
  },
  recentMeta: {
    fontSize: 11,
  },
  recentViews: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  recentViewsText: {
    fontSize: 11,
  },
  emptyRecent: {
    padding: 20,
    borderRadius: 12,
    alignItems: "center",
  },
  emptyRecentText: {
    fontSize: 13,
    textAlign: "center",
  },
});

import { router, useLocalSearchParams, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { checkAdminAuth } from "../login";

function EpisodeForm({
  visible,
  onClose,
  animeId,
  editEpisode,
  onSuccess,
}: {
  visible: boolean;
  onClose: () => void;
  animeId: number;
  editEpisode?: any;
  onSuccess: () => void;
}) {
  const colors = useColors();
  const [number, setNumber] = useState(editEpisode?.number?.toString() ?? "");
  const [title, setTitle] = useState(editEpisode?.title ?? "");
  const [titleAr, setTitleAr] = useState(editEpisode?.titleAr ?? "");
  const [videoUrl, setVideoUrl] = useState(editEpisode?.videoUrl ?? "");
  const [videoUrl480p, setVideoUrl480p] = useState(editEpisode?.videoUrl480p ?? "");
  const [videoUrl720p, setVideoUrl720p] = useState(editEpisode?.videoUrl720p ?? "");
  const [videoUrl1080p, setVideoUrl1080p] = useState(editEpisode?.videoUrl1080p ?? "");
  const [thumbnailUrl, setThumbnailUrl] = useState(editEpisode?.thumbnailUrl ?? "");
  const [duration, setDuration] = useState(editEpisode?.duration?.toString() ?? "");
  const [synopsis, setSynopsis] = useState(editEpisode?.synopsis ?? "");
  const [loading, setLoading] = useState(false);

  const createEpisode = trpc.episodes.create.useMutation();
  const updateEpisode = trpc.episodes.update.useMutation();

  const handleSave = async () => {
    if (!number) {
      Alert.alert("خطأ", "رقم الحلقة مطلوب");
      return;
    }
    setLoading(true);
    try {
      const data = {
        animeId,
        number: parseInt(number),
        title: title || undefined,
        titleAr: titleAr || undefined,
        videoUrl: videoUrl || undefined,
        videoUrl480p: videoUrl480p || undefined,
        videoUrl720p: videoUrl720p || undefined,
        videoUrl1080p: videoUrl1080p || undefined,
        thumbnailUrl: thumbnailUrl || undefined,
        duration: duration ? parseInt(duration) : undefined,
        synopsis: synopsis || undefined,
      };
      if (editEpisode) {
        await updateEpisode.mutateAsync({ id: editEpisode.id, ...data });
      } else {
        await createEpisode.mutateAsync(data);
      }
      onSuccess();
      onClose();
    } catch (err: any) {
      Alert.alert("خطأ", err.message || "فشل في حفظ الحلقة");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <KeyboardAvoidingView
        style={[styles.modalContainer, { backgroundColor: colors.background }]}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
          <Pressable onPress={onClose}>
            <Text style={[styles.modalCancel, { color: colors.error }]}>إلغاء</Text>
          </Pressable>
          <Text style={[styles.modalTitle, { color: colors.foreground }]}>
            {editEpisode ? "تعديل الحلقة" : "إضافة حلقة"}
          </Text>
          <Pressable onPress={handleSave} disabled={loading}>
            <Text style={[styles.modalSave, { color: loading ? colors.muted : colors.primary }]}>
              {loading ? "..." : "حفظ"}
            </Text>
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={styles.modalForm}>
          {[
            { label: "رقم الحلقة *", value: number, setter: setNumber, keyboard: "numeric" as const },
            { label: "العنوان (إنجليزي)", value: title, setter: setTitle },
            { label: "العنوان (عربي)", value: titleAr, setter: setTitleAr },
            { label: "رابط الفيديو الرئيسي", value: videoUrl, setter: setVideoUrl, keyboard: "url" as const },
            { label: "رابط 480p", value: videoUrl480p, setter: setVideoUrl480p, keyboard: "url" as const },
            { label: "رابط 720p", value: videoUrl720p, setter: setVideoUrl720p, keyboard: "url" as const },
            { label: "رابط 1080p", value: videoUrl1080p, setter: setVideoUrl1080p, keyboard: "url" as const },
            { label: "رابط الصورة المصغرة", value: thumbnailUrl, setter: setThumbnailUrl, keyboard: "url" as const },
            { label: "المدة (بالثواني)", value: duration, setter: setDuration, keyboard: "numeric" as const },
          ].map((field) => (
            <View key={field.label} style={styles.formField}>
              <Text style={[styles.formLabel, { color: colors.muted }]}>{field.label}</Text>
              <TextInput
                style={[styles.formInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
                value={field.value}
                onChangeText={field.setter}
                keyboardType={field.keyboard ?? "default"}
                textAlign="right"
                placeholderTextColor={colors.muted}
              />
            </View>
          ))}
          <View style={styles.formField}>
            <Text style={[styles.formLabel, { color: colors.muted }]}>ملخص الحلقة</Text>
            <TextInput
              style={[styles.formInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground, height: 70, textAlignVertical: "top" }]}
              value={synopsis}
              onChangeText={setSynopsis}
              multiline
              textAlign="right"
              placeholderTextColor={colors.muted}
            />
          </View>
          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export default function AdminEpisodesScreen() {
  const { animeId: animeIdStr } = useLocalSearchParams<{ animeId: string }>();
  const animeId = parseInt(animeIdStr ?? "0");
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [showForm, setShowForm] = useState(false);
  const [editEpisode, setEditEpisode] = useState<any>(null);
  const [refreshing, setRefreshing] = useState(false);

  const { data: anime } = trpc.anime.byId.useQuery({ id: animeId });
  const { data: episodes, refetch } = trpc.episodes.byAnimeId.useQuery({ animeId });
  const deleteEpisode = trpc.episodes.delete.useMutation({ onSuccess: () => refetch() });

  useFocusEffect(
    useCallback(() => {
      checkAdminAuth().then((auth) => {
        if (!auth) router.replace("/admin/login" as any);
      });
    }, [])
  );

  const handleDelete = (id: number, number: number) => {
    Alert.alert("حذف الحلقة", `هل تريد حذف الحلقة ${number}؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => deleteEpisode.mutate({ id }) },
    ]);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <IconSymbol name="arrow.left" size={20} color={colors.foreground} />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>الحلقات</Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]} numberOfLines={1}>
            {anime?.titleAr || anime?.title}
          </Text>
        </View>
        <Pressable
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => { setEditEpisode(null); setShowForm(true); }}
        >
          <IconSymbol name="plus" size={18} color="#FFF" />
        </Pressable>
      </View>

      <FlatList
        data={episodes}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={colors.primary} />}
        renderItem={({ item }) => (
          <View style={[styles.episodeItem, { backgroundColor: colors.surface }]}>
            <View style={[styles.episodeNumber, { backgroundColor: colors.primary }]}>
              <Text style={styles.episodeNumberText}>{item.number}</Text>
            </View>
            <View style={styles.episodeInfo}>
              <Text style={[styles.episodeTitle, { color: colors.foreground }]} numberOfLines={1}>
                {item.titleAr || item.title || `الحلقة ${item.number}`}
              </Text>
              <Text style={[styles.episodeMeta, { color: colors.muted }]}>
                {item.videoUrl || item.videoUrl720p ? "✅ رابط متاح" : "⚠️ لا يوجد رابط"}
                {item.duration ? ` • ${Math.floor(item.duration / 60)} دقيقة` : ""}
              </Text>
            </View>
            <View style={styles.actions}>
              <Pressable
                style={[styles.actionBtn, { backgroundColor: colors.primary + "22" }]}
                onPress={() => { setEditEpisode(item); setShowForm(true); }}
              >
                <IconSymbol name="pencil" size={14} color={colors.primary} />
              </Pressable>
              <Pressable
                style={[styles.actionBtn, { backgroundColor: colors.error + "22" }]}
                onPress={() => handleDelete(item.id, item.number)}
              >
                <IconSymbol name="trash" size={14} color={colors.error} />
              </Pressable>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📭</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>لا توجد حلقات</Text>
            <Pressable
              style={[styles.addFirstBtn, { backgroundColor: colors.primary }]}
              onPress={() => { setEditEpisode(null); setShowForm(true); }}
            >
              <Text style={styles.addFirstBtnText}>إضافة أول حلقة</Text>
            </Pressable>
          </View>
        }
      />

      <EpisodeForm
        visible={showForm}
        onClose={() => setShowForm(false)}
        animeId={animeId}
        editEpisode={editEpisode}
        onSuccess={refetch}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
    borderBottomWidth: 0.5,
    gap: 12,
  },
  backBtn: { width: 40, height: 40, justifyContent: "center", alignItems: "center" },
  headerCenter: { flex: 1 },
  headerTitle: { fontSize: 16, fontWeight: "800" },
  headerSubtitle: { fontSize: 11, marginTop: 1 },
  addBtn: { width: 36, height: 36, borderRadius: 18, justifyContent: "center", alignItems: "center" },
  list: { padding: 12, gap: 8 },
  episodeItem: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    gap: 12,
  },
  episodeNumber: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  episodeNumberText: { color: "#FFF", fontWeight: "800", fontSize: 14 },
  episodeInfo: { flex: 1, gap: 3 },
  episodeTitle: { fontSize: 13, fontWeight: "600" },
  episodeMeta: { fontSize: 11 },
  actions: { flexDirection: "row", gap: 6 },
  actionBtn: { width: 30, height: 30, borderRadius: 8, justifyContent: "center", alignItems: "center" },
  emptyState: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: { fontSize: 16, fontWeight: "700" },
  addFirstBtn: { paddingHorizontal: 20, paddingVertical: 10, borderRadius: 20 },
  addFirstBtnText: { color: "#FFF", fontWeight: "700" },
  modalContainer: { flex: 1 },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 0.5,
  },
  modalCancel: { fontSize: 15, fontWeight: "600" },
  modalTitle: { fontSize: 16, fontWeight: "800" },
  modalSave: { fontSize: 15, fontWeight: "700" },
  modalForm: { padding: 16, gap: 4 },
  formField: { marginBottom: 12 },
  formLabel: { fontSize: 12, fontWeight: "600", marginBottom: 6 },
  formInput: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
});

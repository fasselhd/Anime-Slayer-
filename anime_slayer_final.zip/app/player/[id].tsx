"use client";

import * as Brightness from "expo-brightness";
import * as Haptics from "expo-haptics";
import * as ScreenOrientation from "expo-screen-orientation";
import { useKeepAwake } from "expo-keep-awake";
import { VideoView, useVideoPlayer } from "expo-video";
import { useEvent } from "expo";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Dimensions,
  PanResponder,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  FlatList,
  Modal,
  ScrollView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { trpc } from "@/lib/trpc";
import { useInterstitialAd } from "@/hooks/use-interstitial-ad";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");
const SEEK_SECONDS = 10;
const SPEEDS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
const PLACEHOLDER_VIDEO = "https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4";

function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds) || seconds < 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function PlayerScreen() {
  useKeepAwake();
  const router = useRouter();
  const adIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [adCounter, setAdCounter] = useState(0);

  // ─── Safe orientation setup ────────────────────────────────────────
  useEffect(() => {
    if (Platform.OS !== "web") {
      try {
        ScreenOrientation.unlockAsync();
      } catch {}
      return () => {
        try {
          ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
        } catch {}
      };
    }
  }, []);

  // ─── Timed Interstitial Ads (every 5 minutes) ──────────────────────
  const { data: adUnitId } = trpc.settings.get.useQuery({ key: "interstitial_ad_unit_id" });
  const { data: adUnitIdData } = trpc.settings.get.useQuery({ key: "interstitial_ad_unit_id" });
  const showTimedAd = useCallback(() => {
    if (adCounter > 0 && Platform.OS !== "web") {
      // Trigger ad display - the hook will handle it
      // This is just a counter to track when ads should show
    }
  }, [adCounter]);

  useEffect(() => {
    // Show first ad after 30 seconds of watching
    const initialTimer = setTimeout(() => {
      setAdCounter((c) => c + 1);
    }, 30000);

    // Then show every 5 minutes
    adIntervalRef.current = setInterval(() => {
      setAdCounter((c) => c + 1);
    }, 5 * 60 * 1000); // 5 minutes

    return () => {
      clearTimeout(initialTimer);
      if (adIntervalRef.current) clearInterval(adIntervalRef.current);
    };
  }, []);

  const { id } = useLocalSearchParams<{ id: string }>();
  const episodeId = parseInt(id ?? "0");
  const insets = useSafeAreaInsets();

  // ─── Data ─────────────────────────────────────────────────────────
  const { data: episode, isLoading } = trpc.episodes.byId.useQuery({ id: episodeId });
  const { data: anime } = trpc.anime.byId.useQuery(
    { id: episode?.animeId ?? 0 },
    { enabled: !!episode?.animeId }
  );
  const { data: allEpisodes } = trpc.episodes.byAnimeId.useQuery(
    { animeId: episode?.animeId ?? 0 },
    { enabled: !!episode?.animeId }
  );
  const incrementViews = trpc.episodes.incrementViews.useMutation();

  // ─── Player state ─────────────────────────────────────────────────
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isBuffering, setIsBuffering] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [speed, setSpeed] = useState(1.0);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showEpisodeList, setShowEpisodeList] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPreviewTime, setSeekPreviewTime] = useState(0);
  const [isLandscape, setIsLandscape] = useState(false);
  const [selectedQuality, setSelectedQuality] = useState<string>("720p");
  const [isFullscreen, setIsFullscreen] = useState(false);

  // ─── Gesture state ────────────────────────────────────────────────
  const [gestureType, setGestureType] = useState<"brightness" | "volume" | "seek" | null>(null);
  const [gestureValue, setGestureValue] = useState(0);
  const [brightnessLevel, setBrightnessLevel] = useState(0.5);
  const [volumeLevel, setVolumeLevel] = useState(1.0);

  // ─── Refs ─────────────────────────────────────────────────────────
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const gestureOpacity = useRef(new Animated.Value(0)).current;
  const videoRef = useRef<VideoView>(null);
  const gestureStartX = useRef(0);
  const gestureStartY = useRef(0);
  const gestureStartValue = useRef(0);
  const gestureDir = useRef<"h" | "v" | null>(null);
  const progressBarWidth = useRef(0);

  // ─── Get video URL based on selected quality ───────────────────────
  const getVideoUrl = useCallback((): string => {
    if (!episode) return PLACEHOLDER_VIDEO;
    if (selectedQuality === "1080p" && episode.videoUrl1080p) return episode.videoUrl1080p;
    if (selectedQuality === "720p" && episode.videoUrl720p) return episode.videoUrl720p;
    if (selectedQuality === "480p" && episode.videoUrl480p) return episode.videoUrl480p;
    return episode.videoUrl720p || episode.videoUrl || episode.videoUrl480p || PLACEHOLDER_VIDEO;
  }, [episode, selectedQuality]);

  const videoUrl = getVideoUrl();

  // ─── Safe player creation ──────────────────────────────────────────
  const player = useVideoPlayer(videoUrl || PLACEHOLDER_VIDEO, (p) => {
    p.loop = false;
    p.play();
  });

  // ─── Replace video when URL changes ────────────────────────────────────
  useEffect(() => {
    if (videoUrl && player && videoUrl !== PLACEHOLDER_VIDEO) {
      try {
        player.replace({ uri: videoUrl });
      } catch {}
    }
  }, [videoUrl, player]);
  // ─── Events ───────────────────────────────────────────────────────
  const { isPlaying: playerPlaying } = useEvent(player, "playingChange", {
    isPlaying: player.playing,
  });
  const { status } = useEvent(player, "statusChange", { status: player.status });

  useEffect(() => { setIsPlaying(playerPlaying); }, [playerPlaying]);
  useEffect(() => { setIsBuffering(status === "loading"); }, [status]);

  // ─── Increment views ──────────────────────────────────────────────
  useEffect(() => {
    if (episodeId) incrementViews.mutate({ id: episodeId });
  }, [episodeId]);

  // ─── Landscape orientation detection ────────────────────────────────
  useEffect(() => {
    const subscription = Dimensions.addEventListener("change", ({ window }) => {
      setIsLandscape(window.width > window.height);
    });
    return () => subscription?.remove();
  }, []);

  // ─── Progress tracking ────────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isSeeking) {
        const ct = player.currentTime ?? 0;
        setCurrentTime(ct);
        const dur = player.duration ?? 0;
        setDuration(dur);
        const progress = dur > 0 ? (ct / dur) * 100 : 0;
        Animated.timing(progressAnim, {
          toValue: progress,
          duration: 100,
          useNativeDriver: false,
        }).start();
      }
    }, 500);
    return () => clearInterval(interval);
  }, [isSeeking, player, progressAnim]);

  // ─── Save progress ────────────────────────────────────────────────
  useEffect(() => {
    const saveProgress = async () => {
      if (episodeId && currentTime > 0) {
        await AsyncStorage.setItem(`episode_${episodeId}_progress`, currentTime.toString());
      }
    };
    const timer = setTimeout(saveProgress, 2000);
    return () => clearTimeout(timer);
  }, [currentTime, episodeId]);

  // ─── Controls auto-hide ───────────────────────────────────────────
  const resetControlsTimer = useCallback(() => {
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    controlsTimer.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  }, [isPlaying]);

  useEffect(() => {
    if (showControls && isPlaying) resetControlsTimer();
    return () => { if (controlsTimer.current) clearTimeout(controlsTimer.current); };
  }, [showControls, isPlaying, resetControlsTimer]);

  // ─── Safe brightness control ──────────────────────────────────────
  const setBrightness = useCallback((level: number) => {
    if (Platform.OS !== "web") {
      try {
        Brightness.setBrightnessAsync(Math.max(0, Math.min(1, level)));
      } catch {}
    }
  }, []);

  // ─── Safe haptic feedback ─────────────────────────────────────────
  const triggerHaptic = useCallback(() => {
    if (Platform.OS !== "web") {
      try {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } catch {}
    }
  }, []);

  // ─── Play/Pause ───────────────────────────────────────────────────
  const togglePlayPause = useCallback(() => {
    if (player.playing) {
      player.pause();
    } else {
      player.play();
    }
    triggerHaptic();
    resetControlsTimer();
  }, [player, triggerHaptic, resetControlsTimer]);

  // ─── Seek ─────────────────────────────────────────────────────────
  const seek = useCallback((seconds: number) => {
    try {
      player.seekBy(seconds);
      triggerHaptic();
    } catch {}
  }, [player, triggerHaptic]);

  // ─── Speed ────────────────────────────────────────────────────────
  const setPlaybackSpeed = useCallback((newSpeed: number) => {
    try {
      setSpeed(newSpeed);
      player.playbackRate = newSpeed;
      setShowSpeedMenu(false);
      triggerHaptic();
      resetControlsTimer();
    } catch {}
  }, [player, triggerHaptic, resetControlsTimer]);

  // ─── Quality ──────────────────────────────────────────────────────
  const changeQuality = useCallback((quality: string) => {
    try {
      setSelectedQuality(quality);
      setShowQualityMenu(false);
      triggerHaptic();
      resetControlsTimer();
    } catch {}
  }, [triggerHaptic, resetControlsTimer]);

  // ─── PiP (safe - only try if available) ───────────────────────────
  const togglePiP = useCallback(() => {
    try {
      if (typeof (videoRef.current as any)?.startPictureInPicture === "function") {
        (videoRef.current as any).startPictureInPicture();
      }
    } catch {}
  }, []);

  // ─── Fullscreen toggle ─────────────────────────────────────────────
  const toggleFullscreen = useCallback(() => {
    if (Platform.OS !== "web") {
      try {
        if (!isFullscreen) {
          ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_LEFT);
          setIsFullscreen(true);
        } else {
          ScreenOrientation.unlockAsync();
          setIsFullscreen(false);
        }
        triggerHaptic();
      } catch {}
    }
  }, [isFullscreen, triggerHaptic]);

  // ─── Screen tap ────────────────────────────────────────────────────
  const handleScreenTap = useCallback(() => {
    if (isLocked) return;
    if (showSpeedMenu) { setShowSpeedMenu(false); return; }
    if (showQualityMenu) { setShowQualityMenu(false); return; }
    if (showEpisodeList) { setShowEpisodeList(false); return; }
    setShowControls(!showControls);
    if (!showControls) resetControlsTimer();
  }, [isLocked, showSpeedMenu, showQualityMenu, showEpisodeList, showControls, resetControlsTimer]);

  // ─── Gesture responder ─────────────────────────────────────────────
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !isLocked && !showSpeedMenu && !showQualityMenu && !showEpisodeList,
      onMoveShouldSetPanResponder: () => !isLocked && !showSpeedMenu && !showQualityMenu && !showEpisodeList,
      onPanResponderGrant: (e) => {
        gestureStartX.current = e.nativeEvent.locationX;
        gestureStartY.current = e.nativeEvent.locationY;
        gestureStartValue.current = brightnessLevel;
        gestureDir.current = null;
      },
      onPanResponderMove: (e) => {
        const dx = e.nativeEvent.locationX - gestureStartX.current;
        const dy = e.nativeEvent.locationY - gestureStartY.current;
        const absDx = Math.abs(dx);
        const absDy = Math.abs(dy);

        if (!gestureDir.current) {
          if (absDx > absDy && absDx > 10) gestureDir.current = "h";
          else if (absDy > absDx && absDy > 10) gestureDir.current = "v";
        }

        if (gestureDir.current === "h") {
          const seekDelta = (dx / SCREEN_WIDTH) * 60;
          setSeekPreviewTime(Math.max(0, Math.min(duration, currentTime + seekDelta)));
          setGestureType("seek");
          setGestureValue(seekDelta);
        } else if (gestureDir.current === "v") {
          if (gestureStartX.current < SCREEN_WIDTH / 2) {
            const delta = -dy / SCREEN_HEIGHT;
            const newBrightness = Math.max(0, Math.min(1, gestureStartValue.current + delta));
            setBrightnessLevel(newBrightness);
            setBrightness(newBrightness);
            setGestureType("brightness");
            setGestureValue(newBrightness * 100);
          } else {
            const delta = -dy / SCREEN_HEIGHT;
            const newVolume = Math.max(0, Math.min(1, volumeLevel + delta));
            setVolumeLevel(newVolume);
            try { player.volume = newVolume; } catch {}
            setGestureType("volume");
            setGestureValue(newVolume * 100);
          }
        }

        Animated.timing(gestureOpacity, {
          toValue: 1,
          duration: 100,
          useNativeDriver: false,
        }).start();
      },
      onPanResponderRelease: () => {
      if (gestureType === "seek") {
        try { player.seekBy(seekPreviewTime - currentTime); } catch {}
      }
        setGestureType(null);
        Animated.timing(gestureOpacity, {
          toValue: 0,
          duration: 300,
          useNativeDriver: false,
        }).start();
      },
    })
  ).current;

  // ─── Previous/Next episode ────────────────────────────────────────
  const prevEpisode = allEpisodes?.find((ep) => ep.number === (episode?.number ?? 0) - 1);
  const nextEpisode = allEpisodes?.find((ep) => ep.number === (episode?.number ?? 0) + 1);

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: "#000" }]}>
        <ActivityIndicator size="large" color="#E53935" />
      </View>
    );
  }

  if (!episode) {
    return (
      <View style={[styles.container, { backgroundColor: "#000", justifyContent: "center", alignItems: "center" }]}>
        <Text style={{ color: "#fff", marginBottom: 20 }}>لم يتم العثور على الحلقة</Text>
        <TouchableOpacity onPress={() => router.back()} style={styles.playBtn}>
          <Text style={{ color: "#fff" }}>العودة</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, isLandscape && styles.containerLandscape]}>
      <StatusBar hidden={isLandscape} />

      <Pressable style={styles.videoContainer} onPress={handleScreenTap} {...panResponder.panHandlers}>
        <VideoView
          ref={videoRef}
          player={player}
          style={styles.video}
          nativeControls={false}
          allowsFullscreen={false}
          allowsPictureInPicture={true}
        />

        {isBuffering && (
          <View style={styles.bufferingOverlay}>
            <ActivityIndicator size="large" color="#E53935" />
          </View>
        )}

        {/* Gesture feedback */}
        <Animated.View style={[styles.gestureOverlay, { opacity: gestureOpacity }]}>
          <View style={styles.gestureBadge}>
            <Text style={styles.gestureBadgeText}>
              {gestureType === "seek" ? `${gestureValue > 0 ? "+" : ""}${gestureValue.toFixed(0)}s` : `${gestureValue.toFixed(0)}%`}
            </Text>
          </View>
        </Animated.View>

        {/* Top bar */}
        {showControls && (
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => router.back()} style={styles.iconBtn}>
              <Text style={styles.backArrow}>←</Text>
            </TouchableOpacity>
            <View style={styles.titleBlock}>
              <Text style={styles.animeTitleText} numberOfLines={1}>
                {anime?.titleAr || anime?.title}
              </Text>
              <Text style={styles.episodeTitleText} numberOfLines={1}>
                الحلقة {episode?.number}
              </Text>
            </View>
            <TouchableOpacity onPress={() => setIsLocked(!isLocked)} style={styles.iconBtn}>
              <Text style={styles.lockIcon}>{isLocked ? "🔒" : "🔓"}</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Center controls */}
        {showControls && (
          <View style={styles.centerControls}>
            <TouchableOpacity onPress={seek.bind(null, -SEEK_SECONDS)}>
              <Text style={{ fontSize: 32 }}>⏪</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={togglePlayPause} style={styles.playBtn}>
              <Text style={styles.playBtnIcon}>{isPlaying ? "⏸" : "▶"}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={seek.bind(null, SEEK_SECONDS)}>
              <Text style={{ fontSize: 32 }}>⏩</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Bottom controls */}
        {showControls && (
          <View style={styles.bottomBar}>
            <View style={styles.timeControls}>
              <Text style={styles.timeLabel}>{formatTime(currentTime)}</Text>
              <View
                style={styles.progressBar}
                onLayout={(e) => { progressBarWidth.current = e.nativeEvent.layout.width; }}
              >
                <Animated.View
                  style={[
                    styles.progressFill,
                    {
                      width: Animated.multiply(
                        progressAnim,
                        progressBarWidth.current / 100
                      ),
                    },
                  ]}
                />
                <Animated.View
                  style={[
                    styles.progressThumb,
                    {
                      left: Animated.multiply(
                        progressAnim,
                        progressBarWidth.current / 100
                      ),
                    },
                  ]}
                />
              </View>
              <Text style={styles.timeLabel}>{formatTime(duration)}</Text>
            </View>

            <View style={styles.controlsRow}>
              <TouchableOpacity style={styles.controlIcon} onPress={() => setShowQualityMenu(!showQualityMenu)}>
                <Text style={styles.controlIconText}>📺</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlIcon} onPress={() => setShowSpeedMenu(!showSpeedMenu)}>
                <Text style={styles.controlIconText}>⚡</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlIcon} onPress={() => setShowEpisodeList(!showEpisodeList)}>
                <Text style={styles.controlIconText}>☰</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.controlIcon} onPress={togglePiP}>
                <Text style={styles.controlIconText}>📱</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.controlIcon, isFullscreen && styles.controlIconActive]}
                onPress={toggleFullscreen}
              >
                <Text style={styles.controlIconText}>⛶</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Quality menu */}
        {showQualityMenu && (
          <Modal transparent animationType="fade">
            <Pressable style={styles.menuBackdrop} onPress={() => setShowQualityMenu(false)}>
              <View style={styles.menuContainer}>
                {["480p", "720p", "1080p"].map((q) => (
                  <TouchableOpacity
                    key={q}
                    style={[styles.menuItem, selectedQuality === q && styles.menuItemActive]}
                    onPress={() => changeQuality(q)}
                  >
                    <Text style={styles.menuItemText}>{q}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Pressable>
          </Modal>
        )}

        {/* Speed menu */}
        {showSpeedMenu && (
          <Modal transparent animationType="fade">
            <Pressable style={styles.menuBackdrop} onPress={() => setShowSpeedMenu(false)}>
              <View style={styles.menuContainer}>
                {SPEEDS.map((s) => (
                  <TouchableOpacity
                    key={s}
                    style={[styles.menuItem, speed === s && styles.menuItemActive]}
                    onPress={() => setPlaybackSpeed(s)}
                  >
                    <Text style={styles.menuItemText}>{s}x</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Pressable>
          </Modal>
        )}

        {/* Episodes list */}
        {showEpisodeList && allEpisodes && (
          <Modal transparent animationType="fade">
            <Pressable style={styles.menuBackdrop} onPress={() => setShowEpisodeList(false)}>
              <View style={styles.episodeListContainer}>
                <FlatList
                  data={allEpisodes}
                  keyExtractor={(ep) => ep.id.toString()}
                  renderItem={({ item: ep }) => (
                    <TouchableOpacity
                      style={[styles.episodeItem, ep.id === episode.id && styles.episodeItemActive]}
                      onPress={() => {
                        router.push(`/player/${ep.id}`);
                        setShowEpisodeList(false);
                      }}
                    >
                      <Text style={styles.episodeItemText}>الحلقة {ep.number}</Text>
                    </TouchableOpacity>
                  )}
                />
              </View>
            </Pressable>
          </Modal>
        )}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  containerLandscape: {
    width: "100%",
    height: "100%",
  },
  videoContainer: {
    flex: 1,
    backgroundColor: "#000",
    justifyContent: "center",
  },
  video: {
    width: "100%",
    height: "100%",
  },
  topBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  titleBlock: {
    flex: 1,
    marginHorizontal: 12,
  },
  animeTitleText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  episodeTitleText: {
    color: "#aaa",
    fontSize: 12,
    marginTop: 2,
  },
  iconBtn: {
    padding: 8,
  },
  backArrow: {
    fontSize: 20,
  },
  lockIcon: {
    fontSize: 18,
  },
  centerControls: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: [{ translateX: -60 }, { translateY: -32 }],
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 24,
  },
  playBtn: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(229, 57, 53, 0.9)",
    justifyContent: "center",
    alignItems: "center",
  },
  playBtnIcon: {
    fontSize: 28,
    color: "#fff",
  },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: "rgba(0,0,0,0.6)",
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 2,
    marginHorizontal: 8,
    position: "relative",
  },
  progressFill: {
    height: "100%",
    backgroundColor: "#E53935",
    borderRadius: 2,
  },
  progressThumb: {
    position: "absolute",
    top: -5,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: "#E53935",
    marginLeft: -7,
  },
  timeControls: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  timeLabel: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
    minWidth: 40,
  },
  controlsRow: {
    flexDirection: "row",
    gap: 12,
  },
  controlIcon: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 6,
  },
  controlIconActive: {
    backgroundColor: "#E53935",
  },
  controlIconText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },
  menuBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    alignItems: "center",
  },
  menuContainer: {
    backgroundColor: "#1a1a1a",
    borderRadius: 12,
    padding: 8,
    minWidth: 150,
  },
  menuItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  menuItemActive: {
    backgroundColor: "#E53935",
  },
  menuItemText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  episodeListContainer: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.8)",
    margin: 20,
    borderRadius: 12,
    overflow: "hidden",
  },
  episodeItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.1)",
  },
  episodeItemActive: {
    backgroundColor: "#E53935",
  },
  episodeItemText: {
    color: "#fff",
    fontSize: 14,
  },
  bufferingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.3)",
  },
  gestureOverlay: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: [{ translateX: -40 }, { translateY: -40 }],
  },
  gestureBadge: {
    backgroundColor: "rgba(0,0,0,0.8)",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  gestureBadgeText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
});

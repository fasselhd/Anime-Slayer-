/**
 * Web fallback for useInterstitialAd hook.
 * On web, interstitial ads are not supported - this is a no-op.
 * The .native.ts version is used on iOS/Android.
 */
export function useInterstitialAd() {
  // No-op on web
}

import { useEffect } from "react";
import { InteractionManager } from "react-native";
import { InterstitialAd, AdEventType, MobileAds } from "react-native-google-mobile-ads";
import { trpc } from "@/lib/trpc";

// Default fallback ad unit ID
const DEFAULT_AD_UNIT_ID = "ca-app-pub-7032269320751343/1591409450";

// Track if MobileAds has been initialized
let adsInitialized = false;

async function ensureAdsInitialized(): Promise<void> {
  if (adsInitialized) return;
  try {
    await MobileAds().initialize();
    adsInitialized = true;
  } catch {
    // Ignore initialization errors
    adsInitialized = true; // Mark as done to avoid retrying
  }
}

/**
 * Hook that loads and shows an Interstitial ad after the screen is fully interactive.
 * - Waits for all interactions/animations to finish before loading
 * - Shows ad only after it's fully loaded
 * - Wrapped in try/catch to prevent any ad SDK crash from affecting the app
 * - Uses InteractionManager to ensure the screen is ready before showing
 */
export function useInterstitialAd() {
  // Fetch ad unit ID from server settings
  const { data: adUnitId } = trpc.settings.get.useQuery({
    key: "interstitial_ad_unit_id",
  });

  useEffect(() => {
    let cancelled = false;
    let unsubscribeLoaded: (() => void) | null = null;
    let unsubscribeError: (() => void) | null = null;
    let interstitial: InterstitialAd | null = null;

    // Wait for all interactions to finish, then load the ad
    const task = InteractionManager.runAfterInteractions(async () => {
      if (cancelled) return;

      try {
        // Ensure SDK is initialized first
        await ensureAdsInitialized();
        if (cancelled) return;

        // Add a small delay to ensure the Activity/ViewController is fully ready
        await new Promise((resolve) => setTimeout(resolve, 1500));
        if (cancelled) return;

        // Use fetched ad unit ID or fallback to default
        const unitId = adUnitId || DEFAULT_AD_UNIT_ID;
        interstitial = InterstitialAd.createForAdRequest(unitId, {
          requestNonPersonalizedAdsOnly: false,
        });

        unsubscribeLoaded = interstitial.addAdEventListener(AdEventType.LOADED, () => {
          if (cancelled) return;
          try {
            interstitial?.show();
          } catch {
            // Silently ignore show errors
          }
        });

        unsubscribeError = interstitial.addAdEventListener(AdEventType.ERROR, () => {
          // Silently ignore load errors - app continues normally
        });

        // Start loading the ad
        interstitial.load();
      } catch {
        // Silently ignore any initialization errors
      }
    });

    return () => {
      cancelled = true;
      task.cancel();
      try {
        unsubscribeLoaded?.();
        unsubscribeError?.();
      } catch {
        // Ignore cleanup errors
      }
    };
  }, [adUnitId]);
}

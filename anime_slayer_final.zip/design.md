# Anime Slayer (أنمي سلاير) — Design Document

## App Overview
A complete Arabic-language anime streaming mobile app with a dark, vibrant theme inspired by popular anime streaming platforms. Users can browse and watch anime without registration. Admins manage content via a protected dashboard.

---

## Color Palette

| Token | Light | Dark | Usage |
|-------|-------|------|-------|
| `primary` | `#1A6DFF` | `#1A6DFF` | Buttons, active tabs, highlights |
| `background` | `#0D0D0D` | `#0D0D0D` | App background (always dark) |
| `surface` | `#1A1A2E` | `#1A1A2E` | Cards, panels |
| `surface2` | `#16213E` | `#16213E` | Elevated cards |
| `foreground` | `#FFFFFF` | `#FFFFFF` | Primary text |
| `muted` | `#9BA1A6` | `#9BA1A6` | Secondary text |
| `accent` | `#E94560` | `#E94560` | Badges, new labels, ratings |
| `border` | `#2A2A4A` | `#2A2A4A` | Dividers, card borders |
| `success` | `#22C55E` | `#4ADE80` | Success states |
| `warning` | `#F59E0B` | `#FBBF24` | Warnings |
| `error` | `#EF4444` | `#F87171` | Errors |

---

## Screen List

### User-Facing Screens
1. **Home** (`/`) — Featured anime banner, trending, recently added, popular movies
2. **Browse** (`/browse`) — Full catalog with filters (type, genre, year, status)
3. **Search** (`/search`) — Real-time search with results
4. **Anime Detail** (`/anime/[id]`) — Cover, synopsis, episodes list, related anime
5. **Video Player** (`/player/[id]`) — Full-screen video player with controls
6. **Favorites** (`/favorites`) — Locally saved favorites list
7. **Categories** (`/categories`) — Genre/category grid

### Admin Screens
8. **Admin Login** (`/admin/login`) — Password-protected admin access
9. **Admin Dashboard** (`/admin`) — Statistics overview
10. **Admin Anime List** (`/admin/anime`) — Manage all anime entries
11. **Admin Add/Edit Anime** (`/admin/anime/[id]`) — Form to add/edit anime
12. **Admin Episodes** (`/admin/episodes/[animeId]`) — Manage episodes for an anime

---

## Primary Content & Functionality Per Screen

### Home Screen
- **Hero Banner**: Auto-scrolling featured anime (3-5 items) with title, genre tags, watch button
- **Trending Now**: Horizontal scroll of anime cards (poster + title + rating)
- **Recently Added**: Latest additions with "NEW" badge
- **Popular Movies**: Movie-type anime horizontal list
- **AdMob Banner**: At bottom of screen

### Browse Screen
- **Filter Bar**: Type (All/Series/Movie), Genre chips, Status (Ongoing/Completed)
- **Sort Options**: Newest, Most Watched, Rating, A-Z
- **Grid Layout**: 2-column poster grid with title, year, type badge
- **Infinite Scroll / Pagination**
- **AdMob Banner**: At top of content area

### Search Screen
- **Search Input**: Auto-focus, real-time results
- **Results List**: Poster + title + genre + year
- **Empty State**: "ابحث عن أنمي..." placeholder
- **AdMob Banner**: Below search bar

### Anime Detail Screen
- **Header**: Full-width cover image with gradient overlay
- **Info Section**: Title (Arabic + English), year, status, rating, genres
- **Synopsis**: Expandable description
- **Episodes Tab**: Scrollable episode list with thumbnails
- **Related Anime**: Horizontal scroll
- **Watch Button**: Prominent CTA
- **AdMob Banner**: Above episodes list

### Video Player Screen
- **Full-Screen Player**: expo-video with custom controls
- **Episode Navigation**: Previous/Next episode buttons
- **Quality Selector**: If multiple qualities available
- **Keep Awake**: Enabled during playback
- **AdMob Interstitial**: On screen open

### Admin Dashboard
- **Stats Cards**: Total Anime, Total Movies, Total Views, Total Episodes
- **Recent Activity**: Last 5 additions
- **Quick Actions**: Add Anime, Add Movie buttons

---

## Key User Flows

### Watch Anime Flow
1. User opens app → Home screen loads with featured content
2. User taps anime card → Anime Detail screen
3. User taps episode → Video Player opens
4. Video plays full-screen with controls
5. User can navigate to next episode

### Browse & Filter Flow
1. User taps Browse tab → Full catalog loads
2. User selects genre filter → List updates
3. User taps anime → Detail screen

### Search Flow
1. User taps Search tab → Keyboard opens
2. User types → Results appear in real-time
3. User taps result → Detail screen

### Admin Add Anime Flow
1. Admin opens app → Taps hidden admin button or navigates to /admin
2. Admin enters password → Dashboard unlocks
3. Admin taps "Add Anime" → Form screen
4. Admin fills: title, cover image URL, synopsis, genre, year, type, status
5. Admin saves → Anime appears in catalog
6. Admin adds episodes with video URLs

---

## Navigation Structure

```
Tab Bar (User):
├── Home (house.fill)
├── Browse (square.grid.2x2.fill)
├── Search (magnifyingglass)
├── Favorites (heart.fill)
└── Admin (gear) [hidden, accessible via Settings]

Stack Screens:
├── /anime/[id] — Anime Detail
├── /player/[id] — Video Player
├── /admin/login — Admin Login
├── /admin — Admin Dashboard (stack)
├── /admin/anime — Anime Management
├── /admin/anime/add — Add Anime
├── /admin/anime/[id]/edit — Edit Anime
└── /admin/episodes/[animeId] — Episode Management
```

---

## Typography
- **App Font**: System default (San Francisco on iOS, Roboto on Android)
- **Arabic Support**: RTL layout for Arabic text, LTR for English titles
- **Heading**: 24-28px bold
- **Subheading**: 18-20px semibold
- **Body**: 14-16px regular
- **Caption**: 12px muted

---

## Component Library
- `AnimeCard` — Poster card with title, rating, type badge
- `HeroBanner` — Auto-scrolling featured banner
- `EpisodeItem` — Episode row with thumbnail, number, title
- `GenreBadge` — Colored genre chip
- `RatingStars` — Star rating display
- `AdminStatCard` — Dashboard stat with icon and number
- `BannerAd` — AdMob banner wrapper
- `LoadingGrid` — Skeleton loading for grid

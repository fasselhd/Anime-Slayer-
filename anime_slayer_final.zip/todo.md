# Anime Slayer - TODO

## Phase 2: Configuration & Branding
- [x] Copy provided logo to assets/images/icon.png and related paths
- [x] Update app.config.ts with app name, package name (com.aaaaa.aa)
- [x] Update theme colors to dark anime theme
- [x] Update tailwind.config.js with brand colors

## Phase 3: Database & Backend
- [x] Define anime table schema (id, title, titleAr, coverUrl, synopsis, genre, year, type, status, rating, views)
- [x] Define episodes table schema (id, animeId, number, title, videoUrl, thumbnailUrl, duration)
- [x] Define categories table schema
- [x] Run database migrations
- [x] Create server/db.ts query helpers (CRUD for anime, episodes)
- [x] Create tRPC routes (public: list/get anime, admin: create/update/delete)
- [x] Add admin authentication (password-based via AsyncStorage)

## Phase 4: User-Facing Screens
- [x] Home screen with hero banner, trending, recently added, popular movies
- [x] Browse screen with filters (type, genre, status, sort)
- [x] Search screen with real-time results
- [x] Anime Detail screen (cover, info, episodes list, related)
- [x] Video Player screen with expo-video
- [x] Favorites screen (AsyncStorage-based)
- [x] Update tab navigation (Home, Browse, Search, Favorites, Settings)
- [x] Add icon mappings for all tabs

## Phase 5: Admin Dashboard
- [x] Admin login screen (password protection)
- [x] Admin dashboard with statistics (total anime, movies, views, episodes)
- [x] Admin anime list with search and delete
- [x] Add anime form (title, cover, synopsis, genre, year, type, status, rating)
- [x] Edit anime form
- [x] Episode management screen
- [x] Add/edit episode form (number, title, video URL, thumbnail)
- [x] Admin navigation stack

## Phase 6: AdMob & Polish
- [x] Install react-native-google-mobile-ads package
- [x] Configure AdMob app ID in app.config.ts
- [x] Add BannerAd component (ca-app-pub-7032269320751343/1591409450)
- [x] Add banner ad to Home screen
- [x] Add banner ad to Browse screen
- [x] Add banner ad to Search screen
- [x] Add banner ad to Anime Detail screen
- [x] Add banner ad to Favorites screen
- [x] Add banner ad to Profile/Settings screen
- [x] RTL support for Arabic text
- [x] Loading states and error handling
- [x] Pull-to-refresh on lists
- [x] Empty states for all screens
- [x] Profile/Settings screen with admin access button

## تغيير نوع الإعلان
- [x] إزالة جميع إعلانات Banner من الشاشات
- [x] إنشاء hook للإعلان البيني (Interstitial)
- [x] إضافة إعلان بيني يظهر عند فتح الشاشة الرئيسية
- [x] إضافة إعلان بيني عند فتح شاشة التصفح
- [x] إضافة إعلان بيني عند فتح شاشة البحث
- [x] إضافة إعلان بيني عند فتح شاشة تفاصيل الأنمي
- [x] إضافة إعلان بيني عند فتح شاشة المفضلة
- [x] إضافة إعلان بيني عند فتح شاشة الإعدادات

## إصلاحات
- [x] إصلاح مشكلة إغلاق التطبيق عند الفتح (بسبب الإعلان البيني)
- [x] تغيير رمز الدخول للوحة التحكم إلى AbcA_2250
- [x] إخفاء حقل كلمة المرور في لوحة التحكم (secureTextEntry)

## مشغل الفيديو الاحترافي
- [x] تصميم واجهة مشغل احترافية بالكامل
- [x] أزرار تحكم: تشغيل/إيقاف، تقديم/تأخير 10 ثواني
- [x] شريط التقدم مع preview عند السحب
- [x] التحكم بالصوت بالإيماءة (السحب يميناً/يساراً)
- [x] التحكم بالسطوع بالإيماءة (السحب لأعلى/أسفل يسار)
- [x] التحكم بالصوت بالإيماءة (السحب لأعلى/أسفل يمين)
- [x] اختيار سرعة التشغيل (0.25x, 0.5x, 0.75x, 1x, 1.25x, 1.5x, 1.75x, 2x)
- [x] اختيار جودة الفيديو (480p, 720p)
- [x] قفل الشاشة (Lock Screen)
- [x] وضع Picture-in-Picture
- [x] التنقل بين الحلقات (السابقة/التالية)
- [x] عرض معلومات الحلقة والأنمي
- [x] حفظ موضع التشغيل (Resume)
- [x] قائمة الحلقات داخل المشغل
- [x] مؤشر التحميل (Buffering)
- [x] إعلان بيني عند فتح المشغل

## إصلاحات المشغل
- [x] إصلاح الضغط على الحلقة يفتح المشغل مباشرة
- [x] إصلاح تغيير الجودة داخل المشغل يعمل فعلياً
- [x] إضافة دعم العرض بالكامل (Landscape)
- [x] إعادة بناء المشغل بشكل احترافي متكامل

## تحسينات المشغل
- [x] تعيين العرض الكامل (Landscape) مع إمكانية التدوير الحر

- [x] إضافة زر Fullscreen Landscape في المشغل

## إصلاحات الأخطاء
- [x] إصلاح أخطاء صفحة المشغل التي تسبب إغلاق التطبيق
- [x] إعادة تشغيل الخادم

#### ميزة إدارة الإعلانات الدينامية
- [x] إضافة جدول settings في قاعدة البيانات
- [x] إنشاء API endpoints لإدارة رموز الإعلانات
- [x] إنشاء صفحة إعدادات في لوحة التحكم
- [x] تحديث hook الإعلانات ليقرأ من قاعدة البيانات
- [x] تقليل الإعلانات إلى 3 فقط (1 في الحلقات، 3 في المشغل كل 5 دقائق)

/**
 * Web fallback for AdMob initializer - no-op on web.
 */
export async function initializeAds(): Promise<void> {
  // No-op on web
}

/**
 * Native-only AdMob initializer.
 * Called once at app startup to initialize the Google Mobile Ads SDK.
 * This must be called before any ad is loaded or shown.
 */
import { MobileAds } from "react-native-google-mobile-ads";

let initialized = false;

export async function initializeAds(): Promise<void> {
  if (initialized) return;
  try {
    await MobileAds().initialize();
    initialized = true;
  } catch {
    // Ignore errors - app continues without ads
    initialized = true;
  }
}

/** @type {const} */
const themeColors = {
  primary: { light: '#1A6DFF', dark: '#1A6DFF' },
  background: { light: '#0D0D0D', dark: '#0D0D0D' },
  surface: { light: '#1A1A2E', dark: '#1A1A2E' },
  surface2: { light: '#16213E', dark: '#16213E' },
  foreground: { light: '#FFFFFF', dark: '#FFFFFF' },
  muted: { light: '#9BA1A6', dark: '#9BA1A6' },
  accent: { light: '#E94560', dark: '#E94560' },
  border: { light: '#2A2A4A', dark: '#2A2A4A' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  tint: { light: '#1A6DFF', dark: '#1A6DFF' },
};

module.exports = { themeColors };
